// api/utils/validation.js

/**
 * Validation Utility
 * Provides input validation, sanitization, and data verification functions
 */

/**
 * Sanitize input to prevent XSS
 */
function sanitizeInput(input) {
    if (typeof input !== 'string') return input;
    
    return input
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#x27;')
        .replace(/\//g, '&#x2F;')
        .replace(/\\/g, '&#x5C;')
        .replace(/`/g, '&#96;')
        .trim();
}

/**
 * Validate email format
 */
function isValidEmail(email) {
    if (typeof email !== 'string') return false;
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

/**
 * Validate phone number (Ugandan format)
 */
function isValidPhone(phone) {
    if (typeof phone !== 'string') return false;
    
    // Remove all non-numeric characters
    const cleaned = phone.replace(/\D/g, '');
    
    // Check Ugandan formats: +256XXXXXXXXX, 0XXXXXXXXX
    return (cleaned.length === 12 && cleaned.startsWith('256')) ||
           (cleaned.length === 10 && cleaned.startsWith('0'));
}

/**
 * Validate username
 */
function isValidUsername(username) {
    if (typeof username !== 'string') return false;
    
    // Username should be 3-20 characters, alphanumeric and underscore
    const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
    return usernameRegex.test(username);
}

/**
 * Validate password strength
 */
function validatePassword(password) {
    const result = {
        isValid: false,
        score: 0,
        feedback: [],
        strength: 'weak'
    };

    if (typeof password !== 'string') {
        result.feedback.push('Password must be a string');
        return result;
    }

    if (password.length < 8) {
        result.feedback.push('Password must be at least 8 characters long');
    } else {
        result.score += 1;
    }

    if (/[A-Z]/.test(password)) {
        result.score += 1;
    } else {
        result.feedback.push('Add at least one uppercase letter');
    }

    if (/[a-z]/.test(password)) {
        result.score += 1;
    } else {
        result.feedback.push('Add at least one lowercase letter');
    }

    if (/[0-9]/.test(password)) {
        result.score += 1;
    } else {
        result.feedback.push('Add at least one number');
    }

    if (/[^A-Za-z0-9]/.test(password)) {
        result.score += 1;
    } else {
        result.feedback.push('Add at least one special character');
    }

    // Determine strength
    if (result.score >= 5) {
        result.strength = 'strong';
        result.isValid = true;
    } else if (result.score >= 3) {
        result.strength = 'medium';
        result.isValid = true;
    } else {
        result.strength = 'weak';
        result.isValid = false;
    }

    return result;
}

/**
 * Validate amount (positive number)
 */
function isValidAmount(amount) {
    if (amount === null || amount === undefined) return false;
    
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    
    return !isNaN(num) && num > 0 && Number.isFinite(num) && num <= 1000000000; // Max 1 billion
}

/**
 * Validate date
 */
function isValidDate(date) {
    if (!date) return false;
    
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    return dateObj instanceof Date && !isNaN(dateObj.getTime());
}

/**
 * Validate date range
 */
function isValidDateRange(startDate, endDate) {
    if (!startDate || !endDate) return false;
    
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    if (!isValidDate(start) || !isValidDate(end)) return false;
    
    return start <= end;
}

/**
 * Validate role
 */
function isValidRole(role) {
    const validRoles = [
        'admin',
        'chairperson',
        'treasurer',
        'secretary',
        'welfare',
        'discipline',
        'projects',
        'member'
    ];
    
    return validRoles.includes(role);
}

/**
 * Validate transaction type
 */
function isValidTransactionType(type) {
    return ['deposit', 'withdrawal'].includes(type);
}

/**
 * Validate user input for creation
 */
function validateUserInput(userData) {
    const errors = [];

    // Required fields
    if (!userData.username) {
        errors.push('Username is required');
    } else if (!isValidUsername(userData.username)) {
        errors.push('Username must be 3-20 characters and contain only letters, numbers, and underscores');
    }

    if (!userData.password) {
        errors.push('Password is required');
    } else {
        const passwordValidation = validatePassword(userData.password);
        if (!passwordValidation.isValid) {
            errors.push(...passwordValidation.feedback);
        }
    }

    if (!userData.name) {
        errors.push('Full name is required');
    } else if (userData.name.length < 2 || userData.name.length > 100) {
        errors.push('Name must be between 2 and 100 characters');
    }

    if (!userData.role) {
        errors.push('Role is required');
    } else if (!isValidRole(userData.role)) {
        errors.push('Invalid role');
    }

    if (!userData.whatsapp) {
        errors.push('WhatsApp number is required');
    } else if (!isValidPhone(userData.whatsapp)) {
        errors.push('Invalid WhatsApp number format');
    }

    if (userData.email && !isValidEmail(userData.email)) {
        errors.push('Invalid email format');
    }

    return errors.length > 0 ? errors.join('; ') : null;
}

/**
 * Validate user update input
 */
function validateUserUpdate(updateData) {
    const errors = [];

    if (updateData.username !== undefined && !isValidUsername(updateData.username)) {
        errors.push('Username must be 3-20 characters and contain only letters, numbers, and underscores');
    }

    if (updateData.password !== undefined) {
        const passwordValidation = validatePassword(updateData.password);
        if (!passwordValidation.isValid) {
            errors.push(...passwordValidation.feedback);
        }
    }

    if (updateData.name !== undefined && (updateData.name.length < 2 || updateData.name.length > 100)) {
        errors.push('Name must be between 2 and 100 characters');
    }

    if (updateData.role !== undefined && !isValidRole(updateData.role)) {
        errors.push('Invalid role');
    }

    if (updateData.whatsapp !== undefined && !isValidPhone(updateData.whatsapp)) {
        errors.push('Invalid WhatsApp number format');
    }

    if (updateData.email !== undefined && updateData.email && !isValidEmail(updateData.email)) {
        errors.push('Invalid email format');
    }

    return errors.length > 0 ? errors.join('; ') : null;
}

/**
 * Validate transaction input
 */
function validateTransaction(transactionData) {
    const errors = [];

    if (!transactionData.memberId) {
        errors.push('Member ID is required');
    }

    if (!transactionData.amount) {
        errors.push('Amount is required');
    } else if (!isValidAmount(transactionData.amount)) {
        errors.push('Amount must be a positive number');
    }

    if (transactionData.type && !isValidTransactionType(transactionData.type)) {
        errors.push('Invalid transaction type');
    }

    if (transactionData.date && !isValidDate(transactionData.date)) {
        errors.push('Invalid date format');
    }

    if (transactionData.notes && transactionData.notes.length > 500) {
        errors.push('Notes must not exceed 500 characters');
    }

    return errors.length > 0 ? errors.join('; ') : null;
}

/**
 * Validate transaction update
 */
function validateTransactionUpdate(updateData) {
    const errors = [];

    if (updateData.amount !== undefined && !isValidAmount(updateData.amount)) {
        errors.push('Amount must be a positive number');
    }

    if (updateData.type !== undefined && !isValidTransactionType(updateData.type)) {
        errors.push('Invalid transaction type');
    }

    if (updateData.date !== undefined && !isValidDate(updateData.date)) {
        errors.push('Invalid date format');
    }

    if (updateData.notes !== undefined && updateData.notes.length > 500) {
        errors.push('Notes must not exceed 500 characters');
    }

    return errors.length > 0 ? errors.join('; ') : null;
}

/**
 * Validate login input
 */
function validateLoginInput(username, password) {
    if (!username || !password) {
        return 'Username and password are required';
    }

    if (typeof username !== 'string' || typeof password !== 'string') {
        return 'Invalid input format';
    }

    if (username.length < 3 || username.length > 50) {
        return 'Username must be between 3 and 50 characters';
    }

    if (password.length < 6) {
        return 'Password must be at least 6 characters';
    }

    return null;
}

/**
 * Validate ID format (UUID)
 */
function isValidId(id) {
    if (typeof id !== 'string') return false;
    
    // UUID v4 format
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return uuidRegex.test(id);
}

/**
 * Validate pagination parameters
 */
function validatePagination(limit, offset) {
    const validated = {
        limit: 100,
        offset: 0
    };

    if (limit !== undefined) {
        const numLimit = parseInt(limit);
        if (!isNaN(numLimit) && numLimit > 0 && numLimit <= 1000) {
            validated.limit = numLimit;
        }
    }

    if (offset !== undefined) {
        const numOffset = parseInt(offset);
        if (!isNaN(numOffset) && numOffset >= 0) {
            validated.offset = numOffset;
        }
    }

    return validated;
}

/**
 * Validate sort parameters
 */
function validateSort(sortBy, sortOrder) {
    const validSortOrders = ['asc', 'desc'];
    
    return {
        sortBy: sortBy || 'date',
        sortOrder: validSortOrders.includes(sortOrder) ? sortOrder : 'desc'
    };
}

/**
 * Validate date range parameters
 */
function validateDateRange(startDate, endDate) {
    const now = new Date();
    const maxRange = 365 * 2; // 2 years

    let start = startDate ? new Date(startDate) : new Date(now.setMonth(now.getMonth() - 1));
    let end = endDate ? new Date(endDate) : new Date();

    if (!isValidDate(start)) start = new Date(now.setMonth(now.getMonth() - 1));
    if (!isValidDate(end)) end = new Date();

    // Ensure start <= end
    if (start > end) {
        [start, end] = [end, start];
    }

    // Limit range to max 2 years
    const rangeDays = Math.round((end - start) / (1000 * 60 * 60 * 24));
    if (rangeDays > maxRange) {
        start = new Date(end);
        start.setDate(start.getDate() - maxRange);
    }

    return {
        startDate: start.toISOString().split('T')[0],
        endDate: end.toISOString().split('T')[0]
    };
}

module.exports = {
    sanitizeInput,
    isValidEmail,
    isValidPhone,
    isValidUsername,
    validatePassword,
    isValidAmount,
    isValidDate,
    isValidDateRange,
    isValidRole,
    isValidTransactionType,
    validateUserInput,
    validateUserUpdate,
    validateTransaction,
    validateTransactionUpdate,
    validateLoginInput,
    isValidId,
    validatePagination,
    validateSort,
    validateDateRange
};