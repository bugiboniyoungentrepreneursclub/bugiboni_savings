// api/utils/github-storage.js

/**
 * GitHub Storage Utility
 * Handles all file operations with GitHub repository
 * Provides caching, retry logic, and error handling
 */

const fetch = require('node-fetch');
const crypto = require('crypto');

// Cache configuration
const cache = new Map();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

class GitHubStorage {
    constructor() {
        this.token = process.env.GITHUB_TOKEN;
        this.repo = process.env.GITHUB_REPO;
        this.branch = process.env.GITHUB_BRANCH || 'main';
        this.owner = this.repo.split('/')[0];
        this.repoName = this.repo.split('/')[1];
        this.baseUrl = `https://api.github.com/repos/${this.owner}/${this.repoName}/contents/data`;
        this.apiUrl = `https://api.github.com/repos/${this.owner}/${this.repoName}`;
        
        // Rate limiting
        this.rateLimit = {
            remaining: 5000,
            reset: Date.now()
        };
        
        // Request queue for concurrent operations
        this.requestQueue = [];
        this.processingQueue = false;
    }

    /**
     * Generate cache key
     */
    _getCacheKey(filePath) {
        return `github:${filePath}`;
    }

    /**
     * Check if cache is valid
     */
    _isCacheValid(cacheEntry) {
        return cacheEntry && (Date.now() - cacheEntry.timestamp) < CACHE_TTL;
    }

    /**
     * Get from cache
     */
    _getFromCache(key) {
        const cached = cache.get(key);
        if (this._isCacheValid(cached)) {
            return cached.data;
        }
        cache.delete(key);
        return null;
    }

    /**
     * Set in cache
     */
    _setInCache(key, data) {
        cache.set(key, {
            data,
            timestamp: Date.now()
        });
    }

    /**
     * Clear cache
     */
    clearCache(filePath = null) {
        if (filePath) {
            const key = this._getCacheKey(filePath);
            cache.delete(key);
        } else {
            cache.clear();
        }
    }

    /**
     * Check rate limit
     */
    _checkRateLimit() {
        if (this.rateLimit.remaining === 0) {
            const waitTime = this.rateLimit.reset - Date.now();
            if (waitTime > 0) {
                throw new Error(`Rate limit exceeded. Try again in ${Math.ceil(waitTime / 1000)} seconds`);
            }
        }
    }

    /**
     * Update rate limit from response headers
     */
    _updateRateLimit(headers) {
        if (headers.get('x-ratelimit-remaining')) {
            this.rateLimit.remaining = parseInt(headers.get('x-ratelimit-remaining'));
        }
        if (headers.get('x-ratelimit-reset')) {
            this.rateLimit.reset = parseInt(headers.get('x-ratelimit-reset')) * 1000;
        }
    }

    /**
     * Make authenticated GitHub API request
     */
    async _makeRequest(url, options = {}) {
        this._checkRateLimit();

        const defaultOptions = {
            headers: {
                'Authorization': `token ${this.token}`,
                'Accept': 'application/vnd.github.v3+json',
                'User-Agent': 'Bugiboni-Savings-App'
            }
        };

        const requestOptions = {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...options.headers
            }
        };

        try {
            const response = await fetch(url, requestOptions);
            this._updateRateLimit(response.headers);

            if (!response.ok) {
                const error = await response.json().catch(() => ({}));
                throw new Error(error.message || `GitHub API error: ${response.status}`);
            }

            return response;
        } catch (error) {
            console.error('GitHub API request failed:', error);
            throw error;
        }
    }

    /**
     * Read file from GitHub
     */
    async readFile(filePath) {
        // Check cache first
        const cacheKey = this._getCacheKey(filePath);
        const cached = this._getFromCache(cacheKey);
        if (cached) {
            console.log(`Serving ${filePath} from cache`);
            return cached;
        }

        try {
            console.log(`Reading file: ${filePath}`);
            const url = `${this.baseUrl}/${filePath}?ref=${this.branch}`;
            
            const response = await this._makeRequest(url);

            const data = await response.json();
            
            // Decode content from base64
            if (data.content) {
                const content = Buffer.from(data.content, 'base64').toString('utf-8');
                const parsed = JSON.parse(content);
                
                // Cache the parsed data
                this._setInCache(cacheKey, parsed);
                
                return parsed;
            }

            // File doesn't exist, return default structure
            return this.getDefaultData(filePath);

        } catch (error) {
            if (error.message.includes('404')) {
                // File doesn't exist, return default
                console.log(`File ${filePath} not found, returning default`);
                return this.getDefaultData(filePath);
            }
            
            console.error(`Error reading file ${filePath}:`, error);
            throw error;
        }
    }

    /**
     * Write file to GitHub
     */
    async writeFile(filePath, content, message = 'Update data') {
        try {
            console.log(`Writing file: ${filePath}`);

            // Get current file to get its SHA (if it exists)
            let sha = null;
            try {
                const url = `${this.baseUrl}/${filePath}?ref=${this.branch}`;
                const response = await this._makeRequest(url);
                const currentFile = await response.json();
                sha = currentFile.sha;
            } catch (error) {
                // File doesn't exist, will create new
                console.log(`File ${filePath} doesn't exist, will create new`);
            }

            // Prepare content
            const contentEncoded = Buffer.from(JSON.stringify(content, null, 2)).toString('base64');

            // Create commit
            const url = `${this.baseUrl}/${filePath}`;
            const body = {
                message,
                content: contentEncoded,
                branch: this.branch
            };

            if (sha) {
                body.sha = sha;
            }

            const response = await this._makeRequest(url, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });

            const result = await response.json();

            // Clear cache for this file
            this.clearCache(filePath);

            console.log(`Successfully wrote ${filePath}`);
            return result;

        } catch (error) {
            console.error(`Error writing file ${filePath}:`, error);
            throw error;
        }
    }

    /**
     * Delete file from GitHub
     */
    async deleteFile(filePath, message = 'Delete file') {
        try {
            console.log(`Deleting file: ${filePath}`);

            // Get current file SHA
            const url = `${this.baseUrl}/${filePath}?ref=${this.branch}`;
            const response = await this._makeRequest(url);
            const currentFile = await response.json();

            if (!currentFile.sha) {
                throw new Error('File not found');
            }

            // Delete file
            const deleteUrl = `${this.baseUrl}/${filePath}`;
            const body = {
                message,
                sha: currentFile.sha,
                branch: this.branch
            };

            await this._makeRequest(deleteUrl, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });

            // Clear cache
            this.clearCache(filePath);

            console.log(`Successfully deleted ${filePath}`);
            return { success: true };

        } catch (error) {
            console.error(`Error deleting file ${filePath}:`, error);
            throw error;
        }
    }

    /**
     * Get default data structure for file
     */
    getDefaultData(filePath) {
        const defaults = {
            'users.json': [],
            'transactions.json': [],
            'audit.json': [],
            'roles.json': {
                admin: { 
                    permissions: ['manage_users', 'view_reports', 'configure_system', 'view_audit'],
                    level: 100
                },
                chairperson: { 
                    permissions: ['manage_users', 'view_reports', 'view_summaries'],
                    level: 80
                },
                treasurer: { 
                    permissions: ['manage_transactions', 'view_financial_history', 'generate_reports'],
                    level: 70
                },
                secretary: { 
                    permissions: ['view_members', 'view_summaries', 'send_announcements'],
                    level: 60
                },
                welfare: { 
                    permissions: ['view_members', 'view_summaries'],
                    level: 50
                },
                discipline: { 
                    permissions: ['view_members', 'view_summaries'],
                    level: 50
                },
                projects: { 
                    permissions: ['view_members', 'view_summaries'],
                    level: 50
                },
                member: { 
                    permissions: ['view_own_balance', 'view_own_history', 'view_own_profile'],
                    level: 10
                }
            },
            'settings.json': {
                groupName: 'Bugiboni Young Entrepreneurs',
                currency: 'UGX',
                dateFormat: 'YYYY-MM-DD',
                timezone: 'Africa/Kampala',
                requireVerification: true,
                allowWithdrawals: false,
                savingsGoal: 1000000,
                contributionReminders: true,
                whatsappNotifications: true
            }
        };

        return defaults[filePath] || [];
    }

    /**
     * List files in directory
     */
    async listFiles(directory = '') {
        try {
            const url = `${this.apiUrl}/contents/data${directory ? '/' + directory : ''}?ref=${this.branch}`;
            const response = await this._makeRequest(url);
            const files = await response.json();
            
            return files.map(file => ({
                name: file.name,
                path: file.path,
                type: file.type,
                size: file.size,
                sha: file.sha,
                url: file.html_url
            }));

        } catch (error) {
            console.error('Error listing files:', error);
            return [];
        }
    }

    /**
     * Get file metadata
     */
    async getFileInfo(filePath) {
        try {
            const url = `${this.baseUrl}/${filePath}?ref=${this.branch}`;
            const response = await this._makeRequest(url);
            const data = await response.json();

            return {
                name: data.name,
                path: data.path,
                sha: data.sha,
                size: data.size,
                url: data.html_url,
                lastModified: new Date().toISOString() // GitHub doesn't provide this in the API
            };

        } catch (error) {
            console.error('Error getting file info:', error);
            return null;
        }
    }

    /**
     * Check if file exists
     */
    async fileExists(filePath) {
        try {
            const url = `${this.baseUrl}/${filePath}?ref=${this.branch}`;
            await this._makeRequest(url);
            return true;
        } catch (error) {
            return false;
        }
    }

    /**
     * Create backup of file
     */
    async backupFile(filePath) {
        try {
            const content = await this.readFile(filePath);
            const backupPath = `backups/${filePath}.${Date.now()}.backup`;
            await this.writeFile(backupPath, content, `Backup of ${filePath}`);
            return backupPath;
        } catch (error) {
            console.error('Error backing up file:', error);
            throw error;
        }
    }

    /**
     * Restore file from backup
     */
    async restoreFromBackup(backupPath, targetPath) {
        try {
            const content = await this.readFile(backupPath);
            await this.writeFile(targetPath, content, `Restored from ${backupPath}`);
            return true;
        } catch (error) {
            console.error('Error restoring from backup:', error);
            throw error;
        }
    }

    /**
     * Get repository statistics
     */
    async getRepoStats() {
        try {
            const url = `${this.apiUrl}`;
            const response = await this._makeRequest(url);
            const repo = await response.json();

            return {
                name: repo.name,
                fullName: repo.full_name,
                description: repo.description,
                private: repo.private,
                defaultBranch: repo.default_branch,
                size: repo.size,
                updatedAt: repo.updated_at,
                createdAt: repo.created_at
            };

        } catch (error) {
            console.error('Error getting repo stats:', error);
            return null;
        }
    }
}

// Export singleton instance
module.exports = new GitHubStorage();