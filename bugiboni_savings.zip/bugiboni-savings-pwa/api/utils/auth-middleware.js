// api/utils/auth-middleware.js

/**
 * Authentication Middleware
 * Handles JWT verification, role-based access control, and permission checking
 */

const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const JWT_EXPIRES_IN = '8h';

// Token blacklist (consider using Redis in production)
const tokenBlacklist = new Set();

/**
 * Generate JWT token
 */
function generateToken(user) {
    return jwt.sign(
        { 
            id: user.id, 
            username: user.username, 
            role: user.role,
            name: user.name,
            iat: Math.floor(Date.now() / 1000)
        }, 
        JWT_SECRET, 
        { expiresIn: JWT_EXPIRES_IN }
    );
}

/**
 * Verify JWT token
 */
function verifyToken(token) {
    try {
        // Check if token is blacklisted
        if (tokenBlacklist.has(token)) {
            return null;
        }

        const decoded = jwt.verify(token, JWT_SECRET);
        return decoded;
    } catch (error) {
        console.error('Token verification failed:', error.message);
        return null;
    }
}

/**
 * Authenticate token from request
 */
function authenticateToken(token) {
    if (!token) {
        return null;
    }

    return verifyToken(token);
}

/**
 * Check if user has required role
 */
function hasRole(user, requiredRole) {
    if (!user) return false;

    // Admin has all roles
    if (user.role === 'admin') return true;

    // Role hierarchy
    const roleHierarchy = {
        'admin': 100,
        'chairperson': 80,
        'treasurer': 70,
        'secretary': 60,
        'welfare': 50,
        'discipline': 50,
        'projects': 50,
        'member': 10
    };

    const userLevel = roleHierarchy[user.role] || 0;
    const requiredLevel = roleHierarchy[requiredRole] || 0;

    return userLevel >= requiredLevel;
}

/**
 * Check if user has any of the required roles
 */
function hasAnyRole(user, requiredRoles) {
    if (!user) return false;
    if (user.role === 'admin') return true;

    return requiredRoles.some(role => role === user.role);
}

/**
 * Check if user has specific permission
 */
function hasPermission(user, permission) {
    if (!user) return false;

    // Admin has all permissions
    if (user.role === 'admin') return true;

    // Define permissions per role
    const rolePermissions = {
        chairperson: [
            'manage_users',
            'view_reports',
            'view_financial_summary',
            'export_data',
            'view_member_list',
            'send_announcements'
        ],
        treasurer: [
            'manage_transactions',
            'view_financial_history',
            'generate_reports',
            'view_member_balances',
            'send_payment_confirmations',
            'export_data'
        ],
        secretary: [
            'view_member_list',
            'view_financial_summary',
            'view_reports',
            'send_announcements'
        ],
        welfare: [
            'view_member_list',
            'view_financial_summary'
        ],
        discipline: [
            'view_member_list',
            'view_financial_summary'
        ],
        projects: [
            'view_member_list',
            'view_financial_summary'
        ],
        member: [
            'view_own_balance',
            'view_own_transactions',
            'view_own_profile'
        ]
    };

    const userPermissions = rolePermissions[user.role] || [];
    return userPermissions.includes(permission);
}

/**
 * Check if user has all required permissions
 */
function hasAllPermissions(user, permissions) {
    return permissions.every(permission => hasPermission(user, permission));
}

/**
 * Check if user has any of the required permissions
 */
function hasAnyPermission(user, permissions) {
    return permissions.some(permission => hasPermission(user, permission));
}

/**
 * Check if user is accessing their own resource
 */
function isSelf(user, targetUserId) {
    return user && user.id === targetUserId;
}

/**
 * Authorize based on roles
 */
function authorizeRoles(user, allowedRoles) {
    if (!user) return false;
    if (user.role === 'admin') return true;
    return allowedRoles.includes(user.role);
}

/**
 * Authorize based on self or roles
 */
function authorizeSelfOrRoles(user, targetUserId, allowedRoles) {
    if (!user) return false;
    if (isSelf(user, targetUserId)) return true;
    return authorizeRoles(user, allowedRoles);
}

/**
 * Add token to blacklist (logout)
 */
function blacklistToken(token) {
    tokenBlacklist.add(token);
    
    // Auto-remove after expiry (8 hours)
    setTimeout(() => {
        tokenBlacklist.delete(token);
    }, 8 * 60 * 60 * 1000);
}

/**
 * Generate CSRF token
 */
function generateCSRFToken() {
    return crypto.randomBytes(32).toString('hex');
}

/**
 * Validate CSRF token
 */
function validateCSRFToken(token, sessionToken) {
    return token === sessionToken;
}

/**
 * Extract token from request headers or cookies
 */
function extractToken(req) {
    // Check Authorization header
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        return authHeader.substring(7);
    }

    // Check cookies
    if (req.headers.cookie) {
        const cookies = req.headers.cookie.split(';').reduce((acc, cookie) => {
            const [key, value] = cookie.trim().split('=');
            acc[key] = value;
            return acc;
        }, {});

        return cookies.token || null;
    }

    return null;
}

/**
 * Middleware to authenticate requests
 */
function authenticate(req, res, next) {
    const token = extractToken(req);

    if (!token) {
        return res.status(401).json({
            success: false,
            error: 'Authentication required'
        });
    }

    const user = authenticateToken(token);

    if (!user) {
        return res.status(401).json({
            success: false,
            error: 'Invalid or expired token'
        });
    }

    req.user = user;
    next();
}

/**
 * Middleware to authorize based on roles
 */
function authorize(...allowedRoles) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        if (!authorizeRoles(req.user, allowedRoles)) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        next();
    };
}

/**
 * Middleware to authorize self or roles
 */
function authorizeSelfOr(...allowedRoles) {
    return (req, res, next) => {
        if (!req.user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        const targetId = req.params.id || req.query.userId || req.body.userId;

        if (!targetId) {
            return res.status(400).json({
                success: false,
                error: 'Target user ID required'
            });
        }

        if (!authorizeSelfOrRoles(req.user, targetId, allowedRoles)) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        next();
    };
}

/**
 * Get user permissions
 */
function getUserPermissions(user) {
    if (!user) return [];

    if (user.role === 'admin') {
        return ['*']; // All permissions
    }

    const rolePermissions = {
        chairperson: [
            'manage_users',
            'view_reports',
            'view_financial_summary',
            'export_data',
            'view_member_list',
            'send_announcements'
        ],
        treasurer: [
            'manage_transactions',
            'view_financial_history',
            'generate_reports',
            'view_member_balances',
            'send_payment_confirmations',
            'export_data'
        ],
        secretary: [
            'view_member_list',
            'view_financial_summary',
            'view_reports',
            'send_announcements'
        ],
        welfare: [
            'view_member_list',
            'view_financial_summary'
        ],
        discipline: [
            'view_member_list',
            'view_financial_summary'
        ],
        projects: [
            'view_member_list',
            'view_financial_summary'
        ],
        member: [
            'view_own_balance',
            'view_own_transactions',
            'view_own_profile'
        ]
    };

    return rolePermissions[user.role] || [];
}

module.exports = {
    generateToken,
    verifyToken,
    authenticateToken,
    hasRole,
    hasAnyRole,
    hasPermission,
    hasAllPermissions,
    hasAnyPermission,
    isSelf,
    authorizeRoles,
    authorizeSelfOrRoles,
    blacklistToken,
    generateCSRFToken,
    validateCSRFToken,
    extractToken,
    authenticate,
    authorize,
    authorizeSelfOr,
    getUserPermissions,
    tokenBlacklist
};