// api/utils/formatters.js

/**
 * Formatters Utility
 * Provides consistent formatting functions for dates, currency, numbers, etc.
 */

/**
 * Format currency (UGX)
 */
function formatCurrency(amount, options = {}) {
    if (amount === null || amount === undefined) return 'UGX 0';
    
    const num = typeof amount === 'string' ? parseFloat(amount) : amount;
    
    if (isNaN(num)) return 'UGX 0';
    
    const formatter = new Intl.NumberFormat('en-UG', {
        style: 'currency',
        currency: 'UGX',
        minimumFractionDigits: options.decimals || 0,
        maximumFractionDigits: options.decimals || 0,
        ...options
    });
    
    return formatter.format(num);
}

/**
 * Format date
 */
function formatDate(date, format = 'short') {
    if (!date) return 'N/A';
    
    const d = typeof date === 'string' ? new Date(date) : date;
    
    if (isNaN(d.getTime())) return 'Invalid Date';
    
    const formats = {
        short: { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric' 
        },
        long: { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        },
        numeric: { 
            year: 'numeric', 
            month: '2-digit', 
            day: '2-digit' 
        },
        time: { 
            hour: '2-digit', 
            minute: '2-digit' 
        },
        full: { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        },
        iso: {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            timeZoneName: 'short'
        }
    };
    
    return d.toLocaleString('en-UG', formats[format] || formats.short);
}

/**
 * Format phone number (Ugandan format)
 */
function formatPhoneNumber(phone) {
    if (!phone) return '';
    
    // Remove all non-numeric characters
    const cleaned = phone.replace(/\D/g, '');
    
    // Check if it's a Ugandan number
    if (cleaned.length === 12 && cleaned.startsWith('256')) {
        return `+${cleaned.slice(0, 3)} ${cleaned.slice(3, 6)} ${cleaned.slice(6, 9)} ${cleaned.slice(9)}`;
    } else if (cleaned.length === 10 && cleaned.startsWith('0')) {
        return `+256 ${cleaned.slice(1, 4)} ${cleaned.slice(4, 7)} ${cleaned.slice(7)}`;
    } else if (cleaned.length === 9) {
        return `+256 ${cleaned.slice(0, 3)} ${cleaned.slice(3, 6)} ${cleaned.slice(6)}`;
    }
    
    return phone;
}

/**
 * Format number with commas
 */
function formatNumber(num, decimals = 0) {
    if (num === null || num === undefined) return '0';
    
    const n = typeof num === 'string' ? parseFloat(num) : num;
    
    if (isNaN(n)) return '0';
    
    return n.toLocaleString('en-UG', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    });
}

/**
 * Format percentage
 */
function formatPercentage(value, decimals = 1) {
    if (value === null || value === undefined) return '0%';
    
    const v = typeof value === 'string' ? parseFloat(value) : value;
    
    if (isNaN(v)) return '0%';
    
    return `${v.toFixed(decimals)}%`;
}

/**
 * Format file size
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    if (!bytes) return '';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Format duration (seconds to human readable)
 */
function formatDuration(seconds) {
    if (!seconds || seconds < 0) return '0s';
    
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    const parts = [];
    if (days > 0) parts.push(`${days}d`);
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    if (secs > 0 || parts.length === 0) parts.push(`${secs}s`);
    
    return parts.join(' ');
}

/**
 * Format relative time (e.g., "2 hours ago")
 */
function formatRelativeTime(date) {
    if (!date) return '';
    
    const d = typeof date === 'string' ? new Date(date) : date;
    
    if (isNaN(d.getTime())) return '';
    
    const now = new Date();
    const diffMs = now - d;
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);
    const diffWeek = Math.floor(diffDay / 7);
    const diffMonth = Math.floor(diffDay / 30);
    const diffYear = Math.floor(diffDay / 365);
    
    if (diffSec < 60) {
        return diffSec <= 5 ? 'just now' : `${diffSec} seconds ago`;
    } else if (diffMin < 60) {
        return `${diffMin} ${diffMin === 1 ? 'minute' : 'minutes'} ago`;
    } else if (diffHour < 24) {
        return `${diffHour} ${diffHour === 1 ? 'hour' : 'hours'} ago`;
    } else if (diffDay < 7) {
        return `${diffDay} ${diffDay === 1 ? 'day' : 'days'} ago`;
    } else if (diffWeek < 4) {
        return `${diffWeek} ${diffWeek === 1 ? 'week' : 'weeks'} ago`;
    } else if (diffMonth < 12) {
        return `${diffMonth} ${diffMonth === 1 ? 'month' : 'months'} ago`;
    } else {
        return `${diffYear} ${diffYear === 1 ? 'year' : 'years'} ago`;
    }
}

/**
 * Truncate text with ellipsis
 */
function truncateText(text, maxLength = 50) {
    if (!text) return '';
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
}

/**
 * Capitalize first letter of each word
 */
function capitalizeWords(text) {
    if (!text) return '';
    return text.replace(/\b\w/g, char => char.toUpperCase());
}

/**
 * Slugify text (for URLs)
 */
function slugify(text) {
    if (!text) return '';
    
    return text
        .toString()
        .toLowerCase()
        .trim()
        .replace(/\s+/g, '-')           // Replace spaces with -
        .replace(/[^\w\-]+/g, '')        // Remove all non-word chars
        .replace(/\-\-+/g, '-')          // Replace multiple - with single -
        .replace(/^-+/, '')               // Trim - from start
        .replace(/-+$/, '');              // Trim - from end
}

/**
 * Mask sensitive data (e.g., credit card, phone)
 */
function maskData(data, visibleChars = 4, maskChar = '*') {
    if (!data) return '';
    
    const str = String(data);
    if (str.length <= visibleChars) return str;
    
    const maskedLength = str.length - visibleChars;
    const masked = maskChar.repeat(maskedLength);
    const visible = str.slice(-visibleChars);
    
    return masked + visible;
}

/**
 * Format account number
 */
function formatAccountNumber(accountNumber) {
    if (!accountNumber) return '';
    
    const cleaned = accountNumber.replace(/\D/g, '');
    const groups = cleaned.match(/.{1,4}/g);
    
    return groups ? groups.join(' ') : accountNumber;
}

/**
 * Parse amount string to number
 */
function parseAmount(amount) {
    if (typeof amount === 'number') return amount;
    if (!amount) return 0;
    
    // Remove currency symbols, commas, and spaces
    const cleaned = String(amount).replace(/[^0-9.-]/g, '');
    const parsed = parseFloat(cleaned);
    
    return isNaN(parsed) ? 0 : parsed;
}

/**
 * Get ordinal suffix (st, nd, rd, th)
 */
function getOrdinalSuffix(n) {
    const s = ['th', 'st', 'nd', 'rd'];
    const v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
}

/**
 * Format month name
 */
function formatMonth(month, year, format = 'long') {
    const date = new Date(year, month - 1, 1);
    
    const options = {
        month: format
    };
    
    return date.toLocaleDateString('en-UG', options);
}

module.exports = {
    formatCurrency,
    formatDate,
    formatPhoneNumber,
    formatNumber,
    formatPercentage,
    formatFileSize,
    formatDuration,
    formatRelativeTime,
    truncateText,
    capitalizeWords,
    slugify,
    maskData,
    formatAccountNumber,
    parseAmount,
    getOrdinalSuffix,
    formatMonth
};