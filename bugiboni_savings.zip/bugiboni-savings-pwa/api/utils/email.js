// api/utils/email.js

/**
 * Email Utility
 * Handles sending emails for notifications, password resets, etc.
 */

const nodemailer = require('nodemailer');

// Email configuration
const EMAIL_CONFIG = {
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.EMAIL_PORT) || 587,
    secure: process.env.EMAIL_SECURE === 'true',
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD
    },
    from: process.env.EMAIL_FROM || 'noreply@bugiboni.org'
};

// Create transporter
let transporter = null;

/**
 * Initialize email transporter
 */
function initTransporter() {
    if (transporter) return transporter;

    // Check if email is configured
    if (!EMAIL_CONFIG.auth.user || !EMAIL_CONFIG.auth.pass) {
        console.warn('Email not configured. Using console transport.');
        // Create a mock transporter for development
        transporter = {
            sendMail: async (options) => {
                console.log('📧 MOCK EMAIL:', options);
                return { messageId: 'mock-' + Date.now() };
            }
        };
    } else {
        transporter = nodemailer.createTransport(EMAIL_CONFIG);
    }

    return transporter;
}

/**
 * Send email
 */
async function sendEmail(options) {
    try {
        const transport = initTransporter();
        
        const mailOptions = {
            from: options.from || EMAIL_CONFIG.from,
            to: options.to,
            subject: options.subject,
            html: options.html,
            text: options.text,
            attachments: options.attachments || []
        };

        const result = await transport.sendMail(mailOptions);
        
        console.log('Email sent:', result.messageId);
        return { success: true, messageId: result.messageId };

    } catch (error) {
        console.error('Failed to send email:', error);
        return { success: false, error: error.message };
    }
}

/**
 * Send password reset email
 */
async function sendPasswordResetEmail(to, name, resetToken) {
    const resetUrl = `${process.env.APP_URL || 'https://bugiboni.vercel.app'}/reset-password?token=${resetToken}`;
    
    const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    background: #2E7D32;
                    color: white;
                    padding: 20px;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                }
                .content {
                    background: #f5f5f5;
                    padding: 30px;
                    border-radius: 0 0 5px 5px;
                }
                .button {
                    display: inline-block;
                    background: #2E7D32;
                    color: white;
                    padding: 12px 24px;
                    text-decoration: none;
                    border-radius: 5px;
                    margin: 20px 0;
                }
                .footer {
                    margin-top: 20px;
                    font-size: 12px;
                    color: #666;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Bugiboni Young Entrepreneurs</h1>
            </div>
            <div class="content">
                <h2>Password Reset Request</h2>
                <p>Hello ${name},</p>
                <p>We received a request to reset your password for your Bugiboni Savings account.</p>
                <p>Click the button below to reset your password. This link will expire in 1 hour.</p>
                <p style="text-align: center;">
                    <a href="${resetUrl}" class="button">Reset Password</a>
                </p>
                <p>If the button doesn't work, copy and paste this link into your browser:</p>
                <p style="word-break: break-all;">${resetUrl}</p>
                <p>If you didn't request this password reset, please ignore this email or contact your administrator.</p>
            </div>
            <div class="footer">
                <p>This is an automated message, please do not reply to this email.</p>
                <p>&copy; ${new Date().getFullYear()} Bugiboni Young Entrepreneurs. All rights reserved.</p>
            </div>
        </body>
        </html>
    `;

    return sendEmail({
        to,
        subject: 'Password Reset Request - Bugiboni Savings',
        html
    });
}

/**
 * Send welcome email to new member
 */
async function sendWelcomeEmail(to, name, username, temporaryPassword) {
    const loginUrl = `${process.env.APP_URL || 'https://bugiboni.vercel.app'}/login`;
    
    const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    background: #2E7D32;
                    color: white;
                    padding: 20px;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                }
                .content {
                    background: #f5f5f5;
                    padding: 30px;
                    border-radius: 0 0 5px 5px;
                }
                .credentials {
                    background: white;
                    padding: 15px;
                    border-radius: 5px;
                    margin: 20px 0;
                    border-left: 4px solid #2E7D32;
                }
                .button {
                    display: inline-block;
                    background: #2E7D32;
                    color: white;
                    padding: 12px 24px;
                    text-decoration: none;
                    border-radius: 5px;
                    margin: 20px 0;
                }
                .footer {
                    margin-top: 20px;
                    font-size: 12px;
                    color: #666;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Welcome to Bugiboni Young Entrepreneurs!</h1>
            </div>
            <div class="content">
                <h2>Your Account Has Been Created</h2>
                <p>Hello ${name},</p>
                <p>Welcome to the Bugiboni Young Entrepreneurs Savings Management System. Your account has been created successfully.</p>
                
                <div class="credentials">
                    <h3>Your Login Credentials:</h3>
                    <p><strong>Username:</strong> ${username}</p>
                    <p><strong>Temporary Password:</strong> ${temporaryPassword}</p>
                    <p><em>Please change your password after first login.</em></p>
                </div>
                
                <p style="text-align: center;">
                    <a href="${loginUrl}" class="button">Login to Your Account</a>
                </p>
                
                <h3>What You Can Do:</h3>
                <ul>
                    <li>Track your savings and deposits</li>
                    <li>View your transaction history</li>
                    <li>Receive payment confirmations via WhatsApp</li>
                    <li>Stay updated with group announcements</li>
                </ul>
                
                <p>If you have any questions, please contact your group treasurer or chairperson.</p>
            </div>
            <div class="footer">
                <p>This is an automated message, please do not reply to this email.</p>
                <p>&copy; ${new Date().getFullYear()} Bugiboni Young Entrepreneurs. All rights reserved.</p>
            </div>
        </body>
        </html>
    `;

    return sendEmail({
        to,
        subject: 'Welcome to Bugiboni Savings!',
        html
    });
}

/**
 * Send transaction confirmation email
 */
async function sendTransactionConfirmation(to, name, amount, type, newBalance, receiptNumber) {
    const action = type === 'deposit' ? 'deposit' : 'withdrawal';
    const formattedAmount = new Intl.NumberFormat('en-UG', {
        style: 'currency',
        currency: 'UGX',
        minimumFractionDigits: 0
    }).format(amount);
    
    const formattedBalance = new Intl.NumberFormat('en-UG', {
        style: 'currency',
        currency: 'UGX',
        minimumFractionDigits: 0
    }).format(newBalance);
    
    const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    background: #2E7D32;
                    color: white;
                    padding: 20px;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                }
                .content {
                    background: #f5f5f5;
                    padding: 30px;
                    border-radius: 0 0 5px 5px;
                }
                .receipt {
                    background: white;
                    padding: 20px;
                    border-radius: 5px;
                    margin: 20px 0;
                    border: 2px dashed #2E7D32;
                }
                .amount {
                    font-size: 24px;
                    font-weight: bold;
                    color: #2E7D32;
                }
                .balance {
                    font-size: 20px;
                    color: #2E7D32;
                }
                .footer {
                    margin-top: 20px;
                    font-size: 12px;
                    color: #666;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Transaction Confirmation</h1>
            </div>
            <div class="content">
                <h2>Hello ${name},</h2>
                
                <div class="receipt">
                    <h3>Transaction Receipt</h3>
                    <p><strong>Receipt Number:</strong> ${receiptNumber}</p>
                    <p><strong>Date:</strong> ${new Date().toLocaleString()}</p>
                    <p><strong>Transaction Type:</strong> ${type.toUpperCase()}</p>
                    <p><strong>Amount:</strong> <span class="amount">${formattedAmount}</span></p>
                    <p><strong>New Balance:</strong> <span class="balance">${formattedBalance}</span></p>
                </div>
                
                <p>Thank you for saving with Bugiboni Young Entrepreneurs!</p>
                
                <p>If you have any questions about this transaction, please contact your group treasurer.</p>
            </div>
            <div class="footer">
                <p>This is an automated confirmation. Please keep this receipt for your records.</p>
                <p>&copy; ${new Date().getFullYear()} Bugiboni Young Entrepreneurs. All rights reserved.</p>
            </div>
        </body>
        </html>
    `;

    return sendEmail({
        to,
        subject: `Transaction Confirmation - ${receiptNumber}`,
        html
    });
}

/**
 * Send monthly statement
 */
async function sendMonthlyStatement(to, name, month, year, summary, transactions) {
    const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    background: #2E7D32;
                    color: white;
                    padding: 20px;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                }
                .content {
                    background: #f5f5f5;
                    padding: 30px;
                    border-radius: 0 0 5px 5px;
                }
                .summary {
                    background: white;
                    padding: 20px;
                    border-radius: 5px;
                    margin: 20px 0;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 20px 0;
                }
                th {
                    background: #2E7D32;
                    color: white;
                    padding: 10px;
                    text-align: left;
                }
                td {
                    padding: 8px;
                    border-bottom: 1px solid #ddd;
                }
                .total {
                    font-weight: bold;
                    color: #2E7D32;
                }
                .footer {
                    margin-top: 20px;
                    font-size: 12px;
                    color: #666;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Monthly Statement</h1>
                <p>${month} ${year}</p>
            </div>
            <div class="content">
                <h2>Hello ${name},</h2>
                
                <div class="summary">
                    <h3>Summary</h3>
                    <p><strong>Opening Balance:</strong> ${formatCurrency(summary.openingBalance)}</p>
                    <p><strong>Total Deposits:</strong> ${formatCurrency(summary.totalDeposits)}</p>
                    <p><strong>Total Withdrawals:</strong> ${formatCurrency(summary.totalWithdrawals)}</p>
                    <p><strong>Closing Balance:</strong> <span class="total">${formatCurrency(summary.closingBalance)}</span></p>
                    <p><strong>Number of Transactions:</strong> ${summary.transactionCount}</p>
                </div>
                
                <h3>Transaction History</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${transactions.map(t => `
                            <tr>
                                <td>${new Date(t.date).toLocaleDateString()}</td>
                                <td>${t.type}</td>
                                <td>${formatCurrency(t.amount)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
                
                <p>Thank you for saving with Bugiboni Young Entrepreneurs!</p>
            </div>
            <div class="footer">
                <p>This is your automated monthly statement. Please review and contact your treasurer with any questions.</p>
                <p>&copy; ${new Date().getFullYear()} Bugiboni Young Entrepreneurs. All rights reserved.</p>
            </div>
        </body>
        </html>
    `;

    return sendEmail({
        to,
        subject: `Your Monthly Statement - ${month} ${year}`,
        html
    });
}

/**
 * Send group announcement
 */
async function sendGroupAnnouncement(recipients, subject, message, senderName) {
    const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                }
                .header {
                    background: #2E7D32;
                    color: white;
                    padding: 20px;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                }
                .content {
                    background: #f5f5f5;
                    padding: 30px;
                    border-radius: 0 0 5px 5px;
                }
                .message {
                    background: white;
                    padding: 20px;
                    border-radius: 5px;
                    margin: 20px 0;
                    border-left: 4px solid #2E7D32;
                    white-space: pre-line;
                }
                .footer {
                    margin-top: 20px;
                    font-size: 12px;
                    color: #666;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Bugiboni Young Entrepreneurs</h1>
            </div>
            <div class="content">
                <h2>${subject}</h2>
                <p><strong>From:</strong> ${senderName}</p>
                
                <div class="message">
                    ${message.replace(/\n/g, '<br>')}
                </div>
                
                <p>Stay tuned for more updates!</p>
            </div>
            <div class="footer">
                <p>This is an automated announcement. Please do not reply to this email.</p>
                <p>&copy; ${new Date().getFullYear()} Bugiboni Young Entrepreneurs. All rights reserved.</p>
            </div>
        </body>
        </html>
    `;

    // Send to all recipients (in production, you might want to batch these)
    const results = [];
    for (const recipient of recipients) {
        const result = await sendEmail({
            to: recipient.email,
            subject: `[Announcement] ${subject}`,
            html
        });
        results.push({ recipient: recipient.email, ...result });
    }

    return {
        success: results.every(r => r.success),
        sent: results.filter(r => r.success).length,
        failed: results.filter(r => !r.success).length,
        results
    };
}

// Helper to format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-UG', {
        style: 'currency',
        currency: 'UGX',
        minimumFractionDigits: 0
    }).format(amount);
}

module.exports = {
    sendEmail,
    sendPasswordResetEmail,
    sendWelcomeEmail,
    sendTransactionConfirmation,
    sendMonthlyStatement,
    sendGroupAnnouncement
};