// api/utils/audit.js

/**
 * Audit Logging Utility
 * Handles comprehensive audit trail for all system actions
 * Provides logging, retrieval, and analysis of audit events
 */

const { v4: uuidv4 } = require('uuid');
const githubStorage = require('./github-storage');

// In-memory cache for recent audit events
const recentAuditCache = new Map();
const CACHE_SIZE = 1000;
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

class AuditLogger {
    constructor() {
        this.buffer = [];
        this.bufferSize = 50;
        this.flushInterval = 60000; // 1 minute
        this.initialized = false;
        
        // Start periodic flush
        setInterval(() => this.flush(), this.flushInterval);
    }

    /**
     * Initialize audit system
     */
    async init() {
        if (this.initialized) return;
        
        try {
            // Ensure audit file exists
            await githubStorage.readFile('audit.json');
            this.initialized = true;
            console.log('Audit system initialized');
        } catch (error) {
            console.error('Failed to initialize audit system:', error);
        }
    }

    /**
     * Log an audit event
     */
    async log(eventData) {
        const event = {
            id: uuidv4(),
            timestamp: new Date().toISOString(),
            ...eventData,
            metadata: {
                ...eventData.metadata,
                environment: process.env.NODE_ENV || 'development',
                version: process.env.APP_VERSION || '1.0.0'
            }
        };

        // Add to buffer
        this.buffer.push(event);

        // Add to cache
        this._addToCache(event);

        // Flush if buffer is full
        if (this.buffer.length >= this.bufferSize) {
            await this.flush();
        }

        // Also log to console in development
        if (process.env.NODE_ENV === 'development') {
            console.log('AUDIT:', JSON.stringify(event, null, 2));
        }

        return event.id;
    }

    /**
     * Add event to cache
     */
    _addToCache(event) {
        const key = event.id;
        recentAuditCache.set(key, {
            ...event,
            cachedAt: Date.now()
        });

        // Limit cache size
        if (recentAuditCache.size > CACHE_SIZE) {
            const oldestKey = recentAuditCache.keys().next().value;
            recentAuditCache.delete(oldestKey);
        }

        // Auto-expire after TTL
        setTimeout(() => {
            recentAuditCache.delete(key);
        }, CACHE_TTL);
    }

    /**
     * Flush buffer to storage
     */
    async flush() {
        if (this.buffer.length === 0) return;

        const eventsToFlush = [...this.buffer];
        this.buffer = [];

        try {
            const audit = await githubStorage.readFile('audit.json');
            const updatedAudit = [...audit, ...eventsToFlush];
            
            // Keep only last 100,000 events
            if (updatedAudit.length > 100000) {
                updatedAudit.splice(0, updatedAudit.length - 100000);
            }
            
            await githubStorage.writeFile(
                'audit.json',
                updatedAudit,
                `Batch audit: ${eventsToFlush.length} events`
            );

            console.log(`Flushed ${eventsToFlush.length} audit events`);
        } catch (error) {
            console.error('Failed to flush audit events:', error);
            // Put events back in buffer
            this.buffer = [...eventsToFlush, ...this.buffer];
            
            // Keep buffer size in check
            if (this.buffer.length > 1000) {
                this.buffer = this.buffer.slice(-1000);
            }
        }
    }

    /**
     * Get audit events with filtering
     */
    async getEvents(filters = {}) {
        try {
            const audit = await githubStorage.readFile('audit.json');
            
            let filtered = [...audit];

            // Apply filters
            if (filters.action) {
                filtered = filtered.filter(e => e.action === filters.action);
            }

            if (filters.userId) {
                filtered = filtered.filter(e => e.userId === filters.userId);
            }

            if (filters.startDate) {
                filtered = filtered.filter(e => e.timestamp >= filters.startDate);
            }

            if (filters.endDate) {
                filtered = filtered.filter(e => e.timestamp <= filters.endDate);
            }

            if (filters.search) {
                const searchLower = filters.search.toLowerCase();
                filtered = filtered.filter(e => 
                    JSON.stringify(e).toLowerCase().includes(searchLower)
                );
            }

            // Sort by timestamp (newest first)
            filtered.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

            // Apply pagination
            const limit = filters.limit || 100;
            const offset = filters.offset || 0;
            const paginated = filtered.slice(offset, offset + limit);

            return {
                events: paginated,
                total: filtered.length,
                limit,
                offset,
                hasMore: offset + limit < filtered.length
            };

        } catch (error) {
            console.error('Failed to get audit events:', error);
            return {
                events: [],
                total: 0,
                limit: filters.limit || 100,
                offset: filters.offset || 0,
                hasMore: false,
                error: error.message
            };
        }
    }

    /**
     * Get audit event by ID
     */
    async getEventById(eventId) {
        // Check cache first
        if (recentAuditCache.has(eventId)) {
            return recentAuditCache.get(eventId);
        }

        try {
            const audit = await githubStorage.readFile('audit.json');
            return audit.find(e => e.id === eventId) || null;
        } catch (error) {
            console.error('Failed to get audit event:', error);
            return null;
        }
    }

    /**
     * Get user activity summary
     */
    async getUserActivity(userId, days = 30) {
        try {
            const audit = await githubStorage.readFile('audit.json');
            
            const cutoff = new Date();
            cutoff.setDate(cutoff.getDate() - days);

            const userEvents = audit.filter(e => 
                e.userId === userId && 
                new Date(e.timestamp) >= cutoff
            );

            // Group by action
            const actionCounts = {};
            userEvents.forEach(e => {
                actionCounts[e.action] = (actionCounts[e.action] || 0) + 1;
            });

            // Group by day
            const dailyActivity = {};
            userEvents.forEach(e => {
                const day = e.timestamp.split('T')[0];
                if (!dailyActivity[day]) {
                    dailyActivity[day] = {
                        count: 0,
                        actions: []
                    };
                }
                dailyActivity[day].count++;
                if (!dailyActivity[day].actions.includes(e.action)) {
                    dailyActivity[day].actions.push(e.action);
                }
            });

            return {
                userId,
                period: `${days} days`,
                totalEvents: userEvents.length,
                firstEvent: userEvents.length > 0 ? userEvents[userEvents.length - 1].timestamp : null,
                lastEvent: userEvents.length > 0 ? userEvents[0].timestamp : null,
                actionBreakdown: actionCounts,
                dailyActivity: Object.entries(dailyActivity)
                    .map(([date, data]) => ({ date, ...data }))
                    .sort((a, b) => b.date.localeCompare(a.date))
            };

        } catch (error) {
            console.error('Failed to get user activity:', error);
            return null;
        }
    }

    /**
     * Get system activity summary
     */
    async getSystemActivity(days = 7) {
        try {
            const audit = await githubStorage.readFile('audit.json');
            
            const cutoff = new Date();
            cutoff.setDate(cutoff.getDate() - days);

            const recentEvents = audit.filter(e => new Date(e.timestamp) >= cutoff);

            // Overall statistics
            const stats = {
                totalEvents: recentEvents.length,
                uniqueUsers: new Set(recentEvents.map(e => e.userId).filter(Boolean)).size,
                uniqueActions: new Set(recentEvents.map(e => e.action)).size,
                period: `${days} days`
            };

            // Top actions
            const actionCounts = {};
            recentEvents.forEach(e => {
                actionCounts[e.action] = (actionCounts[e.action] || 0) + 1;
            });

            stats.topActions = Object.entries(actionCounts)
                .map(([action, count]) => ({ action, count }))
                .sort((a, b) => b.count - a.count)
                .slice(0, 10);

            // Most active users
            const userCounts = {};
            recentEvents.forEach(e => {
                if (e.userId) {
                    userCounts[e.userId] = userCounts[e.userId] || {
                        count: 0,
                        name: e.userName || 'Unknown'
                    };
                    userCounts[e.userId].count++;
                }
            });

            stats.mostActiveUsers = Object.entries(userCounts)
                .map(([userId, data]) => ({ userId, ...data }))
                .sort((a, b) => b.count - a.count)
                .slice(0, 5);

            // Activity by hour
            const hourlyActivity = Array(24).fill(0);
            recentEvents.forEach(e => {
                const hour = new Date(e.timestamp).getHours();
                hourlyActivity[hour]++;
            });

            stats.hourlyActivity = hourlyActivity.map((count, hour) => ({ hour, count }));

            return stats;

        } catch (error) {
            console.error('Failed to get system activity:', error);
            return null;
        }
    }

    /**
     * Export audit log
     */
    async exportAudit(format = 'json', filters = {}) {
        const { events } = await this.getEvents(filters);

        switch (format) {
            case 'csv':
                return this._convertToCSV(events);
            case 'json':
            default:
                return JSON.stringify(events, null, 2);
        }
    }

    /**
     * Convert audit events to CSV
     */
    _convertToCSV(events) {
        if (events.length === 0) return '';

        // Get all possible headers
        const headers = new Set();
        events.forEach(event => {
            Object.keys(event).forEach(key => headers.add(key));
        });

        const headerArray = Array.from(headers);
        const rows = [headerArray.join(',')];

        events.forEach(event => {
            const row = headerArray.map(header => {
                const value = event[header];
                if (value === null || value === undefined) return '';
                if (typeof value === 'object') return `"${JSON.stringify(value).replace(/"/g, '""')}"`;
                return `"${String(value).replace(/"/g, '""')}"`;
            });
            rows.push(row.join(','));
        });

        return rows.join('\n');
    }

    /**
     * Clean up old audit logs
     */
    async cleanup(retentionDays = 365) {
        try {
            const audit = await githubStorage.readFile('audit.json');
            
            const cutoff = new Date();
            cutoff.setDate(cutoff.getDate() - retentionDays);

            const filtered = audit.filter(e => new Date(e.timestamp) >= cutoff);

            await githubStorage.writeFile(
                'audit.json',
                filtered,
                `Audit cleanup: removed ${audit.length - filtered.length} old events`
            );

            return {
                removed: audit.length - filtered.length,
                remaining: filtered.length
            };

        } catch (error) {
            console.error('Failed to cleanup audit logs:', error);
            return null;
        }
    }
}

// Create and initialize singleton
const auditLogger = new AuditLogger();
auditLogger.init().catch(console.error);

// Convenience function for logging audit events
async function logAuditEvent(event) {
    return auditLogger.log(event);
}

module.exports = {
    auditLogger,
    logAuditEvent,
    getAuditEvents: (filters) => auditLogger.getEvents(filters),
    getAuditEvent: (id) => auditLogger.getEventById(id),
    getUserActivity: (userId, days) => auditLogger.getUserActivity(userId, days),
    getSystemActivity: (days) => auditLogger.getSystemActivity(days),
    exportAudit: (format, filters) => auditLogger.exportAudit(format, filters),
    cleanupAudit: (days) => auditLogger.cleanup(days)
};