// api/users/[id].js

/**
 * Single User API Endpoint
 * Handles operations for individual users
 * 
 * @route GET, PUT, PATCH, DELETE /api/users/:id
 * @access Private (Admin, Chairperson, Self)
 */

const bcrypt = require('bcryptjs');
const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles, authorizeSelf } = require('../utils/auth-middleware');
const { validateUserUpdate, sanitizeInput } = require('../utils/validation');
const { logAuditEvent } = require('../utils/audit');

/**
 * Get single user by ID
 */
async function getUserById(req, res, user, userId) {
    try {
        // Check if user is authorized to view this profile
        if (!authorizeRoles(user, ['admin', 'chairperson']) && !authorizeSelf(user, userId)) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        // Read users
        const users = await githubStorage.readFile('users.json');
        const targetUser = users.find(u => u.id === userId);

        if (!targetUser) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Remove password
        const { password, ...userWithoutPassword } = targetUser;

        // Log access
        await logAuditEvent({
            action: 'USER_VIEWED',
            userId: user.id,
            username: user.username,
            targetUserId: targetUser.id,
            targetUsername: targetUser.username,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            data: userWithoutPassword
        });

    } catch (error) {
        console.error('Error getting user:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to retrieve user'
        });
    }
}

/**
 * Update user (full update)
 */
async function updateUser(req, res, user, userId) {
    try {
        // Check authorization
        if (!authorizeRoles(user, ['admin', 'chairperson'])) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        const updateData = req.body;

        // Validate update data
        const validationError = validateUserUpdate(updateData);
        if (validationError) {
            return res.status(400).json({
                success: false,
                error: validationError
            });
        }

        // Read users
        const users = await githubStorage.readFile('users.json');
        const userIndex = users.findIndex(u => u.id === userId);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Check for duplicate username/email
        if (updateData.username && updateData.username !== users[userIndex].username) {
            if (users.some(u => u.username === updateData.username)) {
                return res.status(400).json({
                    success: false,
                    error: 'Username already exists'
                });
            }
        }

        if (updateData.email && updateData.email !== users[userIndex].email) {
            if (users.some(u => u.email === updateData.email)) {
                return res.status(400).json({
                    success: false,
                    error: 'Email already exists'
                });
            }
        }

        // Store old values for audit
        const oldValues = { ...users[userIndex] };

        // Update user
        const updatedUser = {
            ...users[userIndex],
            name: updateData.name || users[userIndex].name,
            email: updateData.email ? sanitizeInput(updateData.email) : users[userIndex].email,
            whatsapp: updateData.whatsapp ? sanitizeInput(updateData.whatsapp) : users[userIndex].whatsapp,
            role: updateData.role || users[userIndex].role,
            status: updateData.status || users[userIndex].status,
            lastModified: new Date().toISOString(),
            lastModifiedBy: user.id
        };

        // Handle password update if provided
        if (updateData.password) {
            updatedUser.password = await bcrypt.hash(updateData.password, 10);
            updatedUser.passwordChangedAt = new Date().toISOString();
            updatedUser.passwordVersion = (users[userIndex].passwordVersion || 0) + 1;
        }

        users[userIndex] = updatedUser;

        // Save to storage
        await githubStorage.writeFile(
            'users.json',
            users,
            `Update user: ${updatedUser.username}`
        );

        // Log update
        await logAuditEvent({
            action: 'USER_UPDATED',
            userId: user.id,
            username: user.username,
            targetUserId: updatedUser.id,
            targetUsername: updatedUser.username,
            changes: {
                name: oldValues.name !== updatedUser.name,
                email: oldValues.email !== updatedUser.email,
                role: oldValues.role !== updatedUser.role,
                status: oldValues.status !== updatedUser.status,
                password: !!updateData.password
            },
            timestamp: new Date().toISOString()
        });

        // Remove password
        const { password, ...userWithoutPassword } = updatedUser;

        return res.status(200).json({
            success: true,
            data: userWithoutPassword,
            message: 'User updated successfully'
        });

    } catch (error) {
        console.error('Error updating user:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to update user'
        });
    }
}

/**
 * Partially update user (PATCH)
 */
async function patchUser(req, res, user, userId) {
    try {
        // Check authorization
        const isAdmin = authorizeRoles(user, ['admin', 'chairperson']);
        const isSelf = authorizeSelf(user, userId);

        if (!isAdmin && !isSelf) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        const updates = req.body;

        // Restrict what non-admin users can update
        if (!isAdmin) {
            const allowedUpdates = ['name', 'email', 'whatsapp', 'preferences'];
            const invalidUpdates = Object.keys(updates).filter(key => !allowedUpdates.includes(key));
            
            if (invalidUpdates.length > 0) {
                return res.status(403).json({
                    success: false,
                    error: `Cannot update fields: ${invalidUpdates.join(', ')}`
                });
            }
        }

        // Read users
        const users = await githubStorage.readFile('users.json');
        const userIndex = users.findIndex(u => u.id === userId);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        // Store old values
        const oldValues = { ...users[userIndex] };

        // Apply updates
        const updatedUser = {
            ...users[userIndex],
            ...updates,
            lastModified: new Date().toISOString(),
            lastModifiedBy: user.id
        };

        // Handle password separately if provided
        if (updates.password) {
            updatedUser.password = await bcrypt.hash(updates.password, 10);
            updatedUser.passwordChangedAt = new Date().toISOString();
            updatedUser.passwordVersion = (users[userIndex].passwordVersion || 0) + 1;
        }

        users[userIndex] = updatedUser;

        // Save to storage
        await githubStorage.writeFile(
            'users.json',
            users,
            `Patch user: ${updatedUser.username}`
        );

        // Log patch
        await logAuditEvent({
            action: 'USER_PATCHED',
            userId: user.id,
            username: user.username,
            targetUserId: updatedUser.id,
            targetUsername: updatedUser.username,
            fields: Object.keys(updates),
            timestamp: new Date().toISOString()
        });

        // Remove password
        const { password, ...userWithoutPassword } = updatedUser;

        return res.status(200).json({
            success: true,
            data: userWithoutPassword,
            message: 'User updated successfully'
        });

    } catch (error) {
        console.error('Error patching user:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to update user'
        });
    }
}

/**
 * Delete user
 */
async function deleteUser(req, res, user, userId) {
    try {
        // Check authorization (only admin can delete)
        if (!authorizeRoles(user, ['admin'])) {
            return res.status(403).json({
                success: false,
                error: 'Only administrators can delete users'
            });
        }

        // Prevent self-deletion
        if (userId === user.id) {
            return res.status(400).json({
                success: false,
                error: 'Cannot delete your own account'
            });
        }

        // Read users
        const users = await githubStorage.readFile('users.json');
        const userIndex = users.findIndex(u => u.id === userId);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        const deletedUser = users[userIndex];

        // Soft delete or hard delete?
        if (req.query.hard === 'true') {
            // Hard delete - remove from array
            users.splice(userIndex, 1);
        } else {
            // Soft delete - mark as inactive
            users[userIndex].status = 'deleted';
            users[userIndex].deletedAt = new Date().toISOString();
            users[userIndex].deletedBy = user.id;
        }

        // Save to storage
        await githubStorage.writeFile(
            'users.json',
            users,
            `Delete user: ${deletedUser.username}`
        );

        // Log deletion
        await logAuditEvent({
            action: 'USER_DELETED',
            userId: user.id,
            username: user.username,
            targetUserId: deletedUser.id,
            targetUsername: deletedUser.username,
            hardDelete: req.query.hard === 'true',
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            message: `User ${req.query.hard === 'true' ? 'permanently deleted' : 'deactivated'} successfully`
        });

    } catch (error) {
        console.error('Error deleting user:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to delete user'
        });
    }
}

/**
 * Main handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,PUT,PATCH,DELETE,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Get user ID from URL
        const userId = req.query.id || req.url.split('/').pop();

        if (!userId) {
            return res.status(400).json({
                success: false,
                error: 'User ID is required'
            });
        }

        // Route based on HTTP method
        switch (req.method) {
            case 'GET':
                return await getUserById(req, res, user, userId);
            case 'PUT':
                return await updateUser(req, res, user, userId);
            case 'PATCH':
                return await patchUser(req, res, user, userId);
            case 'DELETE':
                return await deleteUser(req, res, user, userId);
            default:
                return res.status(405).json({
                    success: false,
                    error: 'Method not allowed'
                });
        }

    } catch (error) {
        console.error('User API error:', error);
        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};