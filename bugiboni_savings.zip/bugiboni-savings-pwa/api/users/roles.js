// api/users/roles.js

/**
 * User Roles API Endpoint
 * Handles role definitions and assignments
 * 
 * @route GET, POST /api/users/roles
 * @access Private (Admin only)
 */

const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit');

// Role hierarchy and permissions
const ROLE_HIERARCHY = {
    admin: 100,
    chairperson: 80,
    treasurer: 70,
    secretary: 60,
    welfare: 50,
    discipline: 50,
    projects: 50,
    member: 10
};

const DEFAULT_PERMISSIONS = {
    admin: [
        'manage_users',
        'manage_roles',
        'view_audit',
        'configure_system',
        'view_all_reports',
        'export_data',
        'manage_backup',
        'view_financial_summary',
        'manage_transactions',
        'send_announcements'
    ],
    chairperson: [
        'manage_users',
        'view_reports',
        'view_financial_summary',
        'export_data',
        'view_member_list',
        'send_announcements',
        'view_transactions'
    ],
    treasurer: [
        'record_deposits',
        'view_transactions',
        'view_financial_history',
        'generate_reports',
        'view_member_balances',
        'send_payment_confirmations',
        'export_data'
    ],
    secretary: [
        'view_member_list',
        'view_financial_summary',
        'view_reports',
        'send_announcements'
    ],
    welfare: [
        'view_member_list',
        'view_financial_summary'
    ],
    discipline: [
        'view_member_list',
        'view_financial_summary'
    ],
    projects: [
        'view_member_list',
        'view_financial_summary'
    ],
    member: [
        'view_own_balance',
        'view_own_transactions',
        'view_own_profile'
    ]
};

/**
 * Get all roles and permissions
 */
async function getRoles(req, res, user) {
    try {
        // Read roles from storage (or use defaults)
        let roles;
        try {
            roles = await githubStorage.readFile('roles.json');
        } catch (error) {
            // Use defaults if file doesn't exist
            roles = {
                hierarchy: ROLE_HIERARCHY,
                permissions: DEFAULT_PERMISSIONS,
                metadata: {
                    lastUpdated: new Date().toISOString(),
                    version: '1.0.0'
                }
            };
        }

        // Log access
        await logAuditEvent({
            action: 'ROLES_VIEWED',
            userId: user.id,
            username: user.username,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            data: roles
        });

    } catch (error) {
        console.error('Error getting roles:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to retrieve roles'
        });
    }
}

/**
 * Update roles configuration
 */
async function updateRoles(req, res, user) {
    try {
        const { hierarchy, permissions } = req.body;

        // Validate input
        if (!hierarchy || !permissions) {
            return res.status(400).json({
                success: false,
                error: 'Hierarchy and permissions are required'
            });
        }

        // Read existing roles
        let roles;
        try {
            roles = await githubStorage.readFile('roles.json');
        } catch (error) {
            roles = {};
        }

        // Update roles
        const updatedRoles = {
            hierarchy,
            permissions,
            metadata: {
                lastUpdated: new Date().toISOString(),
                updatedBy: user.id,
                updatedByUsername: user.username,
                version: (roles.metadata?.version || '1.0.0') + 1
            }
        };

        // Save to storage
        await githubStorage.writeFile(
            'roles.json',
            updatedRoles,
            `Update roles by ${user.username}`
        );

        // Log update
        await logAuditEvent({
            action: 'ROLES_UPDATED',
            userId: user.id,
            username: user.username,
            changes: {
                hierarchy: !!hierarchy,
                permissions: !!permissions
            },
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            data: updatedRoles,
            message: 'Roles updated successfully'
        });

    } catch (error) {
        console.error('Error updating roles:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to update roles'
        });
    }
}

/**
 * Get permissions for a specific role
 */
async function getRolePermissions(req, res, user) {
    try {
        const { roleName } = req.query;

        if (!roleName) {
            return res.status(400).json({
                success: false,
                error: 'Role name is required'
            });
        }

        // Get permissions
        const permissions = DEFAULT_PERMISSIONS[roleName] || [];

        return res.status(200).json({
            success: true,
            data: {
                role: roleName,
                hierarchy: ROLE_HIERARCHY[roleName] || 0,
                permissions
            }
        });

    } catch (error) {
        console.error('Error getting role permissions:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to retrieve role permissions'
        });
    }
}

/**
 * Assign role to user
 */
async function assignRole(req, res, user) {
    try {
        const { userId, role } = req.body;

        if (!userId || !role) {
            return res.status(400).json({
                success: false,
                error: 'User ID and role are required'
            });
        }

        // Validate role exists
        if (!DEFAULT_PERMISSIONS[role]) {
            return res.status(400).json({
                success: false,
                error: 'Invalid role'
            });
        }

        // Read users
        const users = await githubStorage.readFile('users.json');
        const userIndex = users.findIndex(u => u.id === userId);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        const oldRole = users[userIndex].role;

        // Update role
        users[userIndex].role = role;
        users[userIndex].lastModified = new Date().toISOString();
        users[userIndex].lastModifiedBy = user.id;

        // Save to storage
        await githubStorage.writeFile(
            'users.json',
            users,
            `Assign role ${role} to user ${userId}`
        );

        // Log assignment
        await logAuditEvent({
            action: 'ROLE_ASSIGNED',
            userId: user.id,
            username: user.username,
            targetUserId: userId,
            oldRole,
            newRole: role,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            message: `Role ${role} assigned successfully`
        });

    } catch (error) {
        console.error('Error assigning role:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to assign role'
        });
    }
}

/**
 * Main handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Check authorization (admin only for modifications)
        const requiresAdmin = ['POST', 'PUT'].includes(req.method);
        if (requiresAdmin && !authorizeRoles(user, ['admin'])) {
            return res.status(403).json({
                success: false,
                error: 'Admin privileges required'
            });
        }

        // Route based on method and action
        const { action } = req.query;

        if (action === 'permissions' && req.method === 'GET') {
            return await getRolePermissions(req, res, user);
        }

        if (action === 'assign' && req.method === 'POST') {
            return await assignRole(req, res, user);
        }

        switch (req.method) {
            case 'GET':
                return await getRoles(req, res, user);
            case 'POST':
            case 'PUT':
                return await updateRoles(req, res, user);
            default:
                return res.status(405).json({
                    success: false,
                    error: 'Method not allowed'
                });
        }

    } catch (error) {
        console.error('Roles API error:', error);
        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};

// Export constants for use in other modules
module.exports.constants = {
    ROLE_HIERARCHY,
    DEFAULT_PERMISSIONS
};