// api/users/index.js

/**
 * Users API Endpoint
 * Handles CRUD operations for users
 * 
 * @route GET, POST /api/users
 * @access Private (Admin, Chairperson)
 */

const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles } = require('../utils/auth-middleware');
const { validateUserInput, sanitizeInput } = require('../utils/validation');
const { logAuditEvent } = require('../utils/audit');

/**
 * Get all users (with filtering)
 */
async function getUsers(req, res, user) {
    try {
        const { role, status, search, limit = 100, offset = 0 } = req.query;

        // Read users from storage
        const users = await githubStorage.readFile('users.json');

        // Apply filters
        let filteredUsers = [...users];

        if (role) {
            filteredUsers = filteredUsers.filter(u => u.role === role);
        }

        if (status) {
            filteredUsers = filteredUsers.filter(u => u.status === status);
        }

        if (search) {
            const searchLower = search.toLowerCase();
            filteredUsers = filteredUsers.filter(u => 
                u.name?.toLowerCase().includes(searchLower) ||
                u.username?.toLowerCase().includes(searchLower) ||
                u.email?.toLowerCase().includes(searchLower)
            );
        }

        // Remove passwords from response
        const usersWithoutPasswords = filteredUsers.map(u => {
            const { password, ...userWithoutPassword } = u;
            return userWithoutPassword;
        });

        // Apply pagination
        const paginatedUsers = usersWithoutPasswords.slice(parseInt(offset), parseInt(offset) + parseInt(limit));

        // Log access
        await logAuditEvent({
            action: 'USERS_LISTED',
            userId: user.id,
            username: user.username,
            filters: { role, status, search },
            resultCount: paginatedUsers.length,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            data: paginatedUsers,
            pagination: {
                total: filteredUsers.length,
                limit: parseInt(limit),
                offset: parseInt(offset),
                returned: paginatedUsers.length
            }
        });

    } catch (error) {
        console.error('Error getting users:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to retrieve users'
        });
    }
}

/**
 * Create new user
 */
async function createUser(req, res, user) {
    try {
        const userData = req.body;

        // Validate input
        const validationError = validateUserInput(userData);
        if (validationError) {
            return res.status(400).json({
                success: false,
                error: validationError
            });
        }

        // Read existing users
        const users = await githubStorage.readFile('users.json');

        // Check for duplicate username
        if (users.some(u => u.username === userData.username)) {
            return res.status(400).json({
                success: false,
                error: 'Username already exists'
            });
        }

        // Check for duplicate email
        if (userData.email && users.some(u => u.email === userData.email)) {
            return res.status(400).json({
                success: false,
                error: 'Email already exists'
            });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(userData.password, 10);

        // Create new user object
        const newUser = {
            id: uuidv4(),
            username: sanitizeInput(userData.username.toLowerCase().trim()),
            password: hashedPassword,
            name: sanitizeInput(userData.name.trim()),
            role: userData.role || 'member',
            email: userData.email ? sanitizeInput(userData.email.toLowerCase().trim()) : null,
            whatsapp: userData.whatsapp ? sanitizeInput(userData.whatsapp.trim()) : null,
            status: 'active',
            createdAt: new Date().toISOString(),
            createdBy: user.id,
            lastModified: new Date().toISOString(),
            lastModifiedBy: user.id,
            loginCount: 0,
            passwordVersion: 1,
            preferences: {
                notifications: true,
                language: 'en',
                theme: 'light'
            }
        };

        // Add to users array
        users.push(newUser);

        // Save to storage
        await githubStorage.writeFile(
            'users.json',
            users,
            `Create user: ${newUser.username}`
        );

        // Log creation
        await logAuditEvent({
            action: 'USER_CREATED',
            userId: user.id,
            username: user.username,
            targetUserId: newUser.id,
            targetUsername: newUser.username,
            role: newUser.role,
            timestamp: new Date().toISOString()
        });

        // Remove password from response
        const { password, ...userWithoutPassword } = newUser;

        return res.status(201).json({
            success: true,
            data: userWithoutPassword,
            message: 'User created successfully'
        });

    } catch (error) {
        console.error('Error creating user:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to create user'
        });
    }
}

/**
 * Main handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Check authorization (Admin or Chairperson)
        if (!authorizeRoles(user, ['admin', 'chairperson'])) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        // Route based on HTTP method
        switch (req.method) {
            case 'GET':
                return await getUsers(req, res, user);
            case 'POST':
                return await createUser(req, res, user);
            default:
                return res.status(405).json({
                    success: false,
                    error: 'Method not allowed'
                });
        }

    } catch (error) {
        console.error('Users API error:', error);
        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};