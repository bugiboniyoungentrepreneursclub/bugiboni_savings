// api/transactions/index.js

/**
 * Transactions API Endpoint
 * Handles CRUD operations for financial transactions
 * 
 * @route GET, POST /api/transactions
 * @access Private (Treasurer, Admin)
 */

const { v4: uuidv4 } = require('uuid');
const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles } = require('../utils/auth-middleware');
const { validateTransaction, sanitizeInput } = require('../utils/validation');
const { logAuditEvent } = require('../utils/audit');

/**
 * Get all transactions (with filtering)
 */
async function getTransactions(req, res, user) {
    try {
        const { 
            memberId, 
            startDate, 
            endDate, 
            type,
            minAmount,
            maxAmount,
            recordedBy,
            limit = 100, 
            offset = 0,
            sortBy = 'date',
            sortOrder = 'desc'
        } = req.query;

        // Read transactions from storage
        const transactions = await githubStorage.readFile('transactions.json');

        // Apply filters
        let filteredTransactions = [...transactions];

        if (memberId) {
            filteredTransactions = filteredTransactions.filter(t => t.memberId === memberId);
        }

        if (startDate) {
            filteredTransactions = filteredTransactions.filter(t => t.date >= startDate);
        }

        if (endDate) {
            filteredTransactions = filteredTransactions.filter(t => t.date <= endDate);
        }

        if (type) {
            filteredTransactions = filteredTransactions.filter(t => t.type === type);
        }

        if (minAmount) {
            filteredTransactions = filteredTransactions.filter(t => t.amount >= parseFloat(minAmount));
        }

        if (maxAmount) {
            filteredTransactions = filteredTransactions.filter(t => t.amount <= parseFloat(maxAmount));
        }

        if (recordedBy) {
            filteredTransactions = filteredTransactions.filter(t => t.recordedBy === recordedBy);
        }

        // Sort transactions
        filteredTransactions.sort((a, b) => {
            if (sortOrder === 'desc') {
                return new Date(b[sortBy]) - new Date(a[sortBy]);
            } else {
                return new Date(a[sortBy]) - new Date(b[sortBy]);
            }
        });

        // Apply pagination
        const paginatedTransactions = filteredTransactions.slice(
            parseInt(offset), 
            parseInt(offset) + parseInt(limit)
        );

        // Calculate summary statistics
        const summary = {
            totalAmount: filteredTransactions.reduce((sum, t) => sum + t.amount, 0),
            count: filteredTransactions.length,
            averageAmount: filteredTransactions.length > 0 
                ? filteredTransactions.reduce((sum, t) => sum + t.amount, 0) / filteredTransactions.length 
                : 0,
            minAmount: filteredTransactions.length > 0 
                ? Math.min(...filteredTransactions.map(t => t.amount)) 
                : 0,
            maxAmount: filteredTransactions.length > 0 
                ? Math.max(...filteredTransactions.map(t => t.amount)) 
                : 0
        };

        // Log access
        await logAuditEvent({
            action: 'TRANSACTIONS_LISTED',
            userId: user.id,
            username: user.username,
            filters: { memberId, startDate, endDate, type },
            resultCount: paginatedTransactions.length,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            data: paginatedTransactions,
            summary,
            pagination: {
                total: filteredTransactions.length,
                limit: parseInt(limit),
                offset: parseInt(offset),
                returned: paginatedTransactions.length
            }
        });

    } catch (error) {
        console.error('Error getting transactions:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to retrieve transactions'
        });
    }
}

/**
 * Create new transaction (deposit/withdrawal)
 */
async function createTransaction(req, res, user) {
    try {
        const transactionData = req.body;

        // Validate input
        const validationError = validateTransaction(transactionData);
        if (validationError) {
            return res.status(400).json({
                success: false,
                error: validationError
            });
        }

        // Read existing data
        const transactions = await githubStorage.readFile('transactions.json');
        const users = await githubStorage.readFile('users.json');
        const audit = await githubStorage.readFile('audit.json');

        // Verify member exists
        const member = users.find(u => u.id === transactionData.memberId);
        if (!member) {
            return res.status(400).json({
                success: false,
                error: 'Member not found'
            });
        }

        // Create transaction
        const transaction = {
            id: uuidv4(),
            memberId: transactionData.memberId,
            memberName: member.name,
            amount: parseFloat(transactionData.amount),
            type: transactionData.type || 'deposit',
            date: transactionData.date || new Date().toISOString().split('T')[0],
            time: new Date().toISOString(),
            notes: transactionData.notes ? sanitizeInput(transactionData.notes) : '',
            recordedBy: user.id,
            recordedByName: user.name || user.username,
            verified: false,
            verifiedBy: null,
            verifiedAt: null,
            receiptNumber: generateReceiptNumber(),
            metadata: {
                source: 'api',
                userAgent: req.headers['user-agent'],
                ipAddress: req.headers['x-forwarded-for'] || req.socket.remoteAddress
            }
        };

        // Add to transactions array
        transactions.push(transaction);

        // Create audit entry
        const auditEntry = {
            id: uuidv4(),
            action: 'TRANSACTION_CREATED',
            transactionId: transaction.id,
            userId: user.id,
            userName: user.name || user.username,
            timestamp: transaction.time,
            details: {
                memberId: transaction.memberId,
                memberName: transaction.memberName,
                amount: transaction.amount,
                type: transaction.type
            }
        };
        audit.push(auditEntry);

        // Calculate new balance for member
        const memberTransactions = transactions.filter(t => t.memberId === transaction.memberId);
        const totalSavings = memberTransactions.reduce((sum, t) => {
            return t.type === 'withdrawal' ? sum - t.amount : sum + t.amount;
        }, 0);

        // Save to storage
        await githubStorage.writeFile('transactions.json', transactions, `Add transaction for ${member.name}`);
        await githubStorage.writeFile('audit.json', audit, `Audit: transaction ${transaction.id}`);

        // Log creation
        await logAuditEvent({
            action: 'TRANSACTION_CREATED',
            userId: user.id,
            username: user.username,
            transactionId: transaction.id,
            memberId: transaction.memberId,
            amount: transaction.amount,
            type: transaction.type,
            timestamp: transaction.time
        });

        return res.status(201).json({
            success: true,
            data: transaction,
            totalSavings,
            message: 'Transaction recorded successfully'
        });

    } catch (error) {
        console.error('Error creating transaction:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to create transaction'
        });
    }
}

/**
 * Generate unique receipt number
 */
function generateReceiptNumber() {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `RCP-${timestamp}-${random}`;
}

/**
 * Get transaction summary
 */
async function getTransactionSummary(req, res, user) {
    try {
        const { period = 'all' } = req.query;

        const transactions = await githubStorage.readFile('transactions.json');
        const users = await githubStorage.readFile('users.json');

        let filteredTransactions = [...transactions];
        const now = new Date();

        // Filter by period
        switch (period) {
            case 'today':
                filteredTransactions = transactions.filter(t => 
                    new Date(t.date).toDateString() === now.toDateString()
                );
                break;
            case 'week':
                const weekAgo = new Date(now.setDate(now.getDate() - 7));
                filteredTransactions = transactions.filter(t => 
                    new Date(t.date) >= weekAgo
                );
                break;
            case 'month':
                const monthAgo = new Date(now.setMonth(now.getMonth() - 1));
                filteredTransactions = transactions.filter(t => 
                    new Date(t.date) >= monthAgo
                );
                break;
            case 'year':
                const yearAgo = new Date(now.setFullYear(now.getFullYear() - 1));
                filteredTransactions = transactions.filter(t => 
                    new Date(t.date) >= yearAgo
                );
                break;
        }

        // Calculate summaries
        const summary = {
            totalDeposits: filteredTransactions
                .filter(t => t.type === 'deposit')
                .reduce((sum, t) => sum + t.amount, 0),
            totalWithdrawals: filteredTransactions
                .filter(t => t.type === 'withdrawal')
                .reduce((sum, t) => sum + t.amount, 0),
            count: filteredTransactions.length,
            byMember: {},
            byDate: {}
        };

        summary.netTotal = summary.totalDeposits - summary.totalWithdrawals;

        // Group by member
        filteredTransactions.forEach(t => {
            if (!summary.byMember[t.memberId]) {
                summary.byMember[t.memberId] = {
                    memberName: t.memberName,
                    deposits: 0,
                    withdrawals: 0,
                    count: 0
                };
            }
            if (t.type === 'deposit') {
                summary.byMember[t.memberId].deposits += t.amount;
            } else {
                summary.byMember[t.memberId].withdrawals += t.amount;
            }
            summary.byMember[t.memberId].count++;
        });

        // Group by date
        filteredTransactions.forEach(t => {
            const date = t.date;
            if (!summary.byDate[date]) {
                summary.byDate[date] = {
                    deposits: 0,
                    withdrawals: 0,
                    count: 0
                };
            }
            if (t.type === 'deposit') {
                summary.byDate[date].deposits += t.amount;
            } else {
                summary.byDate[date].withdrawals += t.amount;
            }
            summary.byDate[date].count++;
        });

        return res.status(200).json({
            success: true,
            period,
            summary
        });

    } catch (error) {
        console.error('Error getting transaction summary:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to get transaction summary'
        });
    }
}

/**
 * Main handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Check authorization for mutations
        if (req.method === 'POST' && !authorizeRoles(user, ['treasurer', 'admin'])) {
            return res.status(403).json({
                success: false,
                error: 'Only treasurers and admins can create transactions'
            });
        }

        // Handle special summary endpoint
        if (req.url.includes('/summary') || req.query.summary) {
            return await getTransactionSummary(req, res, user);
        }

        // Route based on HTTP method
        switch (req.method) {
            case 'GET':
                return await getTransactions(req, res, user);
            case 'POST':
                return await createTransaction(req, res, user);
            default:
                return res.status(405).json({
                    success: false,
                    error: 'Method not allowed'
                });
        }

    } catch (error) {
        console.error('Transactions API error:', error);
        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};