// api/transactions/[id].js

/**
 * Single Transaction API Endpoint
 * Handles operations for individual transactions
 * 
 * @route GET, PUT, DELETE /api/transactions/:id
 * @access Private (Treasurer, Admin)
 */

const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles } = require('../utils/auth-middleware');
const { validateTransactionUpdate } = require('../utils/validation');
const { logAuditEvent } = require('../utils/audit');

/**
 * Get single transaction by ID
 */
async function getTransactionById(req, res, user, transactionId) {
    try {
        // Read transactions
        const transactions = await githubStorage.readFile('transactions.json');
        const transaction = transactions.find(t => t.id === transactionId);

        if (!transaction) {
            return res.status(404).json({
                success: false,
                error: 'Transaction not found'
            });
        }

        // Check if user has permission to view
        const isAdmin = authorizeRoles(user, ['admin']);
        const isTreasurer = authorizeRoles(user, ['treasurer']);
        const isOwnTransaction = user.id === transaction.memberId;

        if (!isAdmin && !isTreasurer && !isOwnTransaction) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        // Log access
        await logAuditEvent({
            action: 'TRANSACTION_VIEWED',
            userId: user.id,
            username: user.username,
            transactionId: transaction.id,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            data: transaction
        });

    } catch (error) {
        console.error('Error getting transaction:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to retrieve transaction'
        });
    }
}

/**
 * Update transaction
 */
async function updateTransaction(req, res, user, transactionId) {
    try {
        // Only admins and treasurers can update
        if (!authorizeRoles(user, ['treasurer', 'admin'])) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        const updateData = req.body;

        // Validate update data
        const validationError = validateTransactionUpdate(updateData);
        if (validationError) {
            return res.status(400).json({
                success: false,
                error: validationError
            });
        }

        // Read transactions
        const transactions = await githubStorage.readFile('transactions.json');
        const transactionIndex = transactions.findIndex(t => t.id === transactionId);

        if (transactionIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'Transaction not found'
            });
        }

        // Store old values for audit
        const oldTransaction = { ...transactions[transactionIndex] };

        // Update transaction
        const updatedTransaction = {
            ...oldTransaction,
            amount: updateData.amount || oldTransaction.amount,
            notes: updateData.notes !== undefined ? updateData.notes : oldTransaction.notes,
            date: updateData.date || oldTransaction.date,
            lastModified: new Date().toISOString(),
            lastModifiedBy: user.id,
            modifiedByName: user.name || user.username
        };

        transactions[transactionIndex] = updatedTransaction;

        // Read audit log
        const audit = await githubStorage.readFile('audit.json');

        // Create audit entry
        const auditEntry = {
            id: require('uuid').v4(),
            action: 'TRANSACTION_UPDATED',
            transactionId: updatedTransaction.id,
            userId: user.id,
            userName: user.name || user.username,
            timestamp: new Date().toISOString(),
            changes: {
                amount: oldTransaction.amount !== updatedTransaction.amount,
                notes: oldTransaction.notes !== updatedTransaction.notes,
                date: oldTransaction.date !== updatedTransaction.date
            },
            oldValues: {
                amount: oldTransaction.amount,
                notes: oldTransaction.notes,
                date: oldTransaction.date
            },
            newValues: {
                amount: updatedTransaction.amount,
                notes: updatedTransaction.notes,
                date: updatedTransaction.date
            }
        };
        audit.push(auditEntry);

        // Save to storage
        await githubStorage.writeFile('transactions.json', transactions, `Update transaction ${transactionId}`);
        await githubStorage.writeFile('audit.json', audit, `Audit: transaction update ${transactionId}`);

        // Log update
        await logAuditEvent({
            action: 'TRANSACTION_UPDATED',
            userId: user.id,
            username: user.username,
            transactionId: updatedTransaction.id,
            changes: auditEntry.changes,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            data: updatedTransaction,
            message: 'Transaction updated successfully'
        });

    } catch (error) {
        console.error('Error updating transaction:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to update transaction'
        });
    }
}

/**
 * Delete transaction
 */
async function deleteTransaction(req, res, user, transactionId) {
    try {
        // Only admins can delete transactions
        if (!authorizeRoles(user, ['admin'])) {
            return res.status(403).json({
                success: false,
                error: 'Only administrators can delete transactions'
            });
        }

        // Read transactions
        const transactions = await githubStorage.readFile('transactions.json');
        const transactionIndex = transactions.findIndex(t => t.id === transactionId);

        if (transactionIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'Transaction not found'
            });
        }

        const deletedTransaction = transactions[transactionIndex];

        // Soft delete or hard delete?
        if (req.query.hard === 'true') {
            // Hard delete - remove from array
            transactions.splice(transactionIndex, 1);
        } else {
            // Soft delete - mark as deleted
            transactions[transactionIndex].status = 'deleted';
            transactions[transactionIndex].deletedAt = new Date().toISOString();
            transactions[transactionIndex].deletedBy = user.id;
            transactions[transactionIndex].deletedByName = user.name || user.username;
        }

        // Read audit log
        const audit = await githubStorage.readFile('audit.json');

        // Create audit entry
        const auditEntry = {
            id: require('uuid').v4(),
            action: 'TRANSACTION_DELETED',
            transactionId: deletedTransaction.id,
            userId: user.id,
            userName: user.name || user.username,
            timestamp: new Date().toISOString(),
            hardDelete: req.query.hard === 'true',
            transaction: req.query.hard === 'true' ? deletedTransaction : null
        };
        audit.push(auditEntry);

        // Save to storage
        await githubStorage.writeFile('transactions.json', transactions, `Delete transaction ${transactionId}`);
        await githubStorage.writeFile('audit.json', audit, `Audit: transaction delete ${transactionId}`);

        // Log deletion
        await logAuditEvent({
            action: 'TRANSACTION_DELETED',
            userId: user.id,
            username: user.username,
            transactionId: deletedTransaction.id,
            amount: deletedTransaction.amount,
            memberId: deletedTransaction.memberId,
            hardDelete: req.query.hard === 'true',
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            message: `Transaction ${req.query.hard === 'true' ? 'permanently deleted' : 'deleted'} successfully`
        });

    } catch (error) {
        console.error('Error deleting transaction:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to delete transaction'
        });
    }
}

/**
 * Verify transaction
 */
async function verifyTransaction(req, res, user, transactionId) {
    try {
        // Only treasurers and admins can verify
        if (!authorizeRoles(user, ['treasurer', 'admin'])) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        // Read transactions
        const transactions = await githubStorage.readFile('transactions.json');
        const transactionIndex = transactions.findIndex(t => t.id === transactionId);

        if (transactionIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'Transaction not found'
            });
        }

        // Update verification status
        transactions[transactionIndex].verified = true;
        transactions[transactionIndex].verifiedBy = user.id;
        transactions[transactionIndex].verifiedByName = user.name || user.username;
        transactions[transactionIndex].verifiedAt = new Date().toISOString();

        // Read audit log
        const audit = await githubStorage.readFile('audit.json');

        // Create audit entry
        const auditEntry = {
            id: require('uuid').v4(),
            action: 'TRANSACTION_VERIFIED',
            transactionId: transactionId,
            userId: user.id,
            userName: user.name || user.username,
            timestamp: new Date().toISOString()
        };
        audit.push(auditEntry);

        // Save to storage
        await githubStorage.writeFile('transactions.json', transactions, `Verify transaction ${transactionId}`);
        await githubStorage.writeFile('audit.json', audit, `Audit: transaction verify ${transactionId}`);

        // Log verification
        await logAuditEvent({
            action: 'TRANSACTION_VERIFIED',
            userId: user.id,
            username: user.username,
            transactionId: transactionId,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            data: transactions[transactionIndex],
            message: 'Transaction verified successfully'
        });

    } catch (error) {
        console.error('Error verifying transaction:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to verify transaction'
        });
    }
}

/**
 * Main handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,PUT,DELETE,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Get transaction ID from URL
        const transactionId = req.query.id || req.url.split('/').pop();

        if (!transactionId) {
            return res.status(400).json({
                success: false,
                error: 'Transaction ID is required'
            });
        }

        // Handle verify action
        if (req.query.action === 'verify' && req.method === 'POST') {
            return await verifyTransaction(req, res, user, transactionId);
        }

        // Route based on HTTP method
        switch (req.method) {
            case 'GET':
                return await getTransactionById(req, res, user, transactionId);
            case 'PUT':
                return await updateTransaction(req, res, user, transactionId);
            case 'DELETE':
                return await deleteTransaction(req, res, user, transactionId);
            default:
                return res.status(405).json({
                    success: false,
                    error: 'Method not allowed'
                });
        }

    } catch (error) {
        console.error('Transaction API error:', error);
        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};