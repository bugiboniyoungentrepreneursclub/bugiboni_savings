// api/transactions/member.js

/**
 * Member Transactions API Endpoint
 * Gets transactions for a specific member
 * 
 * @route GET /api/transactions/member
 * @access Private (Member, Treasurer, Admin)
 */

const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles, authorizeSelf } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit');

module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow GET requests
    if (req.method !== 'GET') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Get member ID from query
        const { memberId, startDate, endDate, limit = 50, offset = 0 } = req.query;

        if (!memberId) {
            return res.status(400).json({
                success: false,
                error: 'Member ID is required'
            });
        }

        // Check authorization
        const isAdmin = authorizeRoles(user, ['admin']);
        const isTreasurer = authorizeRoles(user, ['treasurer']);
        const isSelf = authorizeSelf(user, memberId);

        if (!isAdmin && !isTreasurer && !isSelf) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        // Read transactions
        const transactions = await githubStorage.readFile('transactions.json');
        const users = await githubStorage.readFile('users.json');

        // Find member
        const member = users.find(u => u.id === memberId);
        if (!member) {
            return res.status(404).json({
                success: false,
                error: 'Member not found'
            });
        }

        // Filter transactions for member
        let memberTransactions = transactions.filter(t => t.memberId === memberId);

        // Apply date filters
        if (startDate) {
            memberTransactions = memberTransactions.filter(t => t.date >= startDate);
        }

        if (endDate) {
            memberTransactions = memberTransactions.filter(t => t.date <= endDate);
        }

        // Sort by date (newest first)
        memberTransactions.sort((a, b) => new Date(b.date) - new Date(a.date));

        // Calculate running balance
        let runningBalance = 0;
        const transactionsWithBalance = memberTransactions.map(t => {
            if (t.type === 'deposit') {
                runningBalance += t.amount;
            } else {
                runningBalance -= t.amount;
            }
            return {
                ...t,
                runningBalance
            };
        });

        // Apply pagination
        const paginatedTransactions = transactionsWithBalance.slice(
            parseInt(offset),
            parseInt(offset) + parseInt(limit)
        );

        // Calculate summary
        const summary = {
            totalDeposits: memberTransactions
                .filter(t => t.type === 'deposit')
                .reduce((sum, t) => sum + t.amount, 0),
            totalWithdrawals: memberTransactions
                .filter(t => t.type === 'withdrawal')
                .reduce((sum, t) => sum + t.amount, 0),
            count: memberTransactions.length,
            currentBalance: runningBalance,
            firstTransaction: memberTransactions.length > 0 
                ? memberTransactions[memberTransactions.length - 1].date 
                : null,
            lastTransaction: memberTransactions.length > 0 
                ? memberTransactions[0].date 
                : null
        };

        summary.netTotal = summary.totalDeposits - summary.totalWithdrawals;

        // Log access
        await logAuditEvent({
            action: 'MEMBER_TRANSACTIONS_VIEWED',
            userId: user.id,
            username: user.username,
            memberId: memberId,
            memberName: member.name,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            member: {
                id: member.id,
                name: member.name,
                username: member.username,
                whatsapp: member.whatsapp
            },
            summary,
            transactions: paginatedTransactions,
            pagination: {
                total: memberTransactions.length,
                limit: parseInt(limit),
                offset: parseInt(offset),
                returned: paginatedTransactions.length
            }
        });

    } catch (error) {
        console.error('Error getting member transactions:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to retrieve member transactions'
        });
    }
};