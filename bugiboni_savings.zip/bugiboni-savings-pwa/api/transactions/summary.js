// api/transactions/summary.js

/**
 * Transaction Summary API Endpoint
 * Provides aggregated transaction data and statistics
 * 
 * @route GET /api/transactions/summary
 * @access Private (Treasurer, Admin, Chairperson)
 */

const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit');

module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow GET requests
    if (req.method !== 'GET') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Check authorization
        if (!authorizeRoles(user, ['admin', 'treasurer', 'chairperson'])) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        const { period = 'month', groupBy = 'day' } = req.query;

        // Read data
        const transactions = await githubStorage.readFile('transactions.json');
        const users = await githubStorage.readFile('users.json');

        // Calculate date range based on period
        const now = new Date();
        let startDate = new Date();

        switch (period) {
            case 'today':
                startDate = new Date(now.setHours(0, 0, 0, 0));
                break;
            case 'week':
                startDate = new Date(now.setDate(now.getDate() - 7));
                break;
            case 'month':
                startDate = new Date(now.setMonth(now.getMonth() - 1));
                break;
            case 'quarter':
                startDate = new Date(now.setMonth(now.getMonth() - 3));
                break;
            case 'year':
                startDate = new Date(now.setFullYear(now.getFullYear() - 1));
                break;
            case 'all':
                startDate = new Date(0);
                break;
        }

        // Filter transactions by date range
        const filteredTransactions = transactions.filter(t => 
            new Date(t.date) >= startDate
        );

        // Overall statistics
        const overall = {
            totalTransactions: filteredTransactions.length,
            totalDeposits: filteredTransactions
                .filter(t => t.type === 'deposit')
                .reduce((sum, t) => sum + t.amount, 0),
            totalWithdrawals: filteredTransactions
                .filter(t => t.type === 'withdrawal')
                .reduce((sum, t) => sum + t.amount, 0),
            averageTransaction: filteredTransactions.length > 0
                ? filteredTransactions.reduce((sum, t) => sum + t.amount, 0) / filteredTransactions.length
                : 0,
            uniqueMembers: new Set(filteredTransactions.map(t => t.memberId)).size
        };

        overall.netTotal = overall.totalDeposits - overall.totalWithdrawals;

        // Group by member
        const byMember = {};
        filteredTransactions.forEach(t => {
            if (!byMember[t.memberId]) {
                byMember[t.memberId] = {
                    memberId: t.memberId,
                    memberName: t.memberName,
                    deposits: 0,
                    withdrawals: 0,
                    count: 0,
                    transactions: []
                };
            }
            if (t.type === 'deposit') {
                byMember[t.memberId].deposits += t.amount;
            } else {
                byMember[t.memberId].withdrawals += t.amount;
            }
            byMember[t.memberId].count++;
            byMember[t.memberId].transactions.push(t.id);
        });

        // Group by time period
        const byTime = {};
        filteredTransactions.forEach(t => {
            let key;
            const date = new Date(t.date);

            switch (groupBy) {
                case 'hour':
                    key = `${date.toISOString().split('T')[0]} ${date.getHours()}:00`;
                    break;
                case 'day':
                    key = date.toISOString().split('T')[0];
                    break;
                case 'week':
                    const week = Math.ceil(date.getDate() / 7);
                    key = `${date.getFullYear()}-W${week}`;
                    break;
                case 'month':
                    key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
                    break;
                case 'year':
                    key = date.getFullYear().toString();
                    break;
            }

            if (!byTime[key]) {
                byTime[key] = {
                    period: key,
                    deposits: 0,
                    withdrawals: 0,
                    count: 0
                };
            }
            if (t.type === 'deposit') {
                byTime[key].deposits += t.amount;
            } else {
                byTime[key].withdrawals += t.amount;
            }
            byTime[key].count++;
        });

        // Get top contributors
        const topContributors = Object.values(byMember)
            .sort((a, b) => (b.deposits - b.withdrawals) - (a.deposits - a.withdrawals))
            .slice(0, 10)
            .map(m => ({
                memberId: m.memberId,
                memberName: m.memberName,
                netContribution: m.deposits - m.withdrawals,
                deposits: m.deposits,
                withdrawals: m.withdrawals,
                transactionCount: m.count
            }));

        // Get recent activity
        const recentActivity = filteredTransactions
            .sort((a, b) => new Date(b.date) - new Date(a.date))
            .slice(0, 20)
            .map(t => ({
                id: t.id,
                date: t.date,
                memberName: t.memberName,
                amount: t.amount,
                type: t.type,
                recordedByName: t.recordedByName
            }));

        // Log access
        await logAuditEvent({
            action: 'TRANSACTION_SUMMARY_VIEWED',
            userId: user.id,
            username: user.username,
            period,
            groupBy,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            period,
            groupBy,
            dateRange: {
                start: startDate.toISOString(),
                end: new Date().toISOString()
            },
            overall,
            byMember: Object.values(byMember),
            byTime: Object.values(byTime).sort((a, b) => a.period.localeCompare(b.period)),
            topContributors,
            recentActivity
        });

    } catch (error) {
        console.error('Error getting transaction summary:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to get transaction summary'
        });
    }
};