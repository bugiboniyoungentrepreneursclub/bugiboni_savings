// api/reports/individual.js

/**
 * Individual Member Report API Endpoint
 * Generates detailed savings report for a single member
 * 
 * @route GET /api/reports/individual
 * @access Private (Member, Treasurer, Admin, Chairperson)
 */

const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles, authorizeSelf } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit');
const { formatCurrency, formatDate } = require('../utils/formatters');

module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow GET requests
    if (req.method !== 'GET') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Get parameters
        const { memberId, startDate, endDate, format = 'json' } = req.query;

        if (!memberId) {
            return res.status(400).json({
                success: false,
                error: 'Member ID is required'
            });
        }

        // Check authorization
        const isAdmin = authorizeRoles(user, ['admin']);
        const isTreasurer = authorizeRoles(user, ['treasurer']);
        const isChairperson = authorizeRoles(user, ['chairperson']);
        const isSelf = authorizeSelf(user, memberId);

        if (!isAdmin && !isTreasurer && !isChairperson && !isSelf) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        // Read data
        const users = await githubStorage.readFile('users.json');
        const transactions = await githubStorage.readFile('transactions.json');

        // Find member
        const member = users.find(u => u.id === memberId);
        if (!member) {
            return res.status(404).json({
                success: false,
                error: 'Member not found'
            });
        }

        // Filter transactions for member
        let memberTransactions = transactions.filter(t => t.memberId === memberId);

        // Apply date filters
        if (startDate) {
            memberTransactions = memberTransactions.filter(t => t.date >= startDate);
        }
        if (endDate) {
            memberTransactions = memberTransactions.filter(t => t.date <= endDate);
        }

        // Sort by date
        memberTransactions.sort((a, b) => new Date(a.date) - new Date(b.date));

        // Calculate running balance
        let runningBalance = 0;
        const transactionsWithBalance = memberTransactions.map(t => {
            if (t.type === 'deposit') {
                runningBalance += t.amount;
            } else {
                runningBalance -= t.amount;
            }
            return {
                ...t,
                runningBalance
            };
        });

        // Calculate statistics
        const totalDeposits = memberTransactions
            .filter(t => t.type === 'deposit')
            .reduce((sum, t) => sum + t.amount, 0);

        const totalWithdrawals = memberTransactions
            .filter(t => t.type === 'withdrawal')
            .reduce((sum, t) => sum + t.amount, 0);

        // Group by month
        const monthlySummary = {};
        memberTransactions.forEach(t => {
            const month = t.date.substring(0, 7); // YYYY-MM
            if (!monthlySummary[month]) {
                monthlySummary[month] = {
                    deposits: 0,
                    withdrawals: 0,
                    count: 0
                };
            }
            if (t.type === 'deposit') {
                monthlySummary[month].deposits += t.amount;
            } else {
                monthlySummary[month].withdrawals += t.amount;
            }
            monthlySummary[month].count++;
        });

        // Prepare report data
        const reportData = {
            generatedAt: new Date().toISOString(),
            generatedBy: {
                id: user.id,
                name: user.name,
                role: user.role
            },
            member: {
                id: member.id,
                name: member.name,
                username: member.username,
                role: member.role,
                whatsapp: member.whatsapp,
                email: member.email,
                joinedAt: member.createdAt,
                status: member.status
            },
            dateRange: {
                start: startDate || 'All time',
                end: endDate || 'Present',
                totalDays: startDate && endDate ? 
                    Math.round((new Date(endDate) - new Date(startDate)) / (1000 * 60 * 60 * 24)) : 
                    'All time'
            },
            summary: {
                totalDeposits,
                totalWithdrawals,
                netSavings: totalDeposits - totalWithdrawals,
                currentBalance: runningBalance,
                transactionCount: memberTransactions.length,
                averageDeposit: memberTransactions.filter(t => t.type === 'deposit').length > 0 ?
                    totalDeposits / memberTransactions.filter(t => t.type === 'deposit').length : 0,
                averageWithdrawal: memberTransactions.filter(t => t.type === 'withdrawal').length > 0 ?
                    totalWithdrawals / memberTransactions.filter(t => t.type === 'withdrawal').length : 0,
                firstTransaction: memberTransactions.length > 0 ? memberTransactions[0].date : null,
                lastTransaction: memberTransactions.length > 0 ? memberTransactions[memberTransactions.length - 1].date : null
            },
            monthlySummary: Object.entries(monthlySummary).map(([month, data]) => ({
                month,
                ...data,
                netChange: data.deposits - data.withdrawals
            })).sort((a, b) => a.month.localeCompare(b.month)),
            transactions: transactionsWithBalance.reverse(), // Most recent first
            statistics: {
                consistencyScore: calculateConsistencyScore(memberTransactions),
                savingsRate: calculateSavingsRate(memberTransactions),
                projectedAnnual: runningBalance * 12,
                rank: await calculateMemberRank(memberId, users, transactions)
            }
        };

        // Log report generation
        await logAuditEvent({
            action: 'INDIVIDUAL_REPORT_GENERATED',
            userId: user.id,
            username: user.username,
            memberId: member.id,
            memberName: member.name,
            dateRange: { startDate, endDate },
            format,
            timestamp: new Date().toISOString()
        });

        // Handle different output formats
        if (format === 'pdf' || format === 'csv') {
            // For PDF/CSV, we'll return the data and let client handle formatting
            return res.status(200).json({
                success: true,
                format,
                data: reportData
            });
        }

        // Default JSON response
        return res.status(200).json({
            success: true,
            data: reportData
        });

    } catch (error) {
        console.error('Error generating individual report:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to generate individual report'
        });
    }
};

/**
 * Calculate consistency score based on regular savings
 */
function calculateConsistencyScore(transactions) {
    if (transactions.length === 0) return 0;

    // Group by month
    const months = {};
    transactions.forEach(t => {
        if (t.type === 'deposit') {
            const month = t.date.substring(0, 7);
            months[month] = (months[month] || 0) + 1;
        }
    });

    const monthCount = Object.keys(months).length;
    const expectedMonths = Math.min(12, monthCount);
    
    // Score based on months with deposits
    return Math.min(100, Math.round((monthCount / expectedMonths) * 100));
}

/**
 * Calculate savings rate (deposits vs potential)
 */
function calculateSavingsRate(transactions) {
    const deposits = transactions.filter(t => t.type === 'deposit');
    if (deposits.length === 0) return 0;

    const totalDeposits = deposits.reduce((sum, t) => sum + t.amount, 0);
    const months = new Set(deposits.map(t => t.date.substring(0, 7))).size;
    const averageMonthly = totalDeposits / months;

    // Assuming target savings of 100,000 UGX per month
    const targetMonthly = 100000;
    return Math.min(100, Math.round((averageMonthly / targetMonthly) * 100));
}

/**
 * Calculate member's rank among all members
 */
async function calculateMemberRank(memberId, users, transactions) {
    // Calculate balances for all members
    const balances = {};
    
    transactions.forEach(t => {
        if (!balances[t.memberId]) {
            balances[t.memberId] = 0;
        }
        if (t.type === 'deposit') {
            balances[t.memberId] += t.amount;
        } else {
            balances[t.memberId] -= t.amount;
        }
    });

    // Sort members by balance
    const sortedMembers = Object.entries(balances)
        .sort(([, a], [, b]) => b - a)
        .map(([id]) => id);

    const rank = sortedMembers.indexOf(memberId) + 1;
    const totalMembers = sortedMembers.length;

    return {
        rank,
        totalMembers,
        percentile: Math.round((rank / totalMembers) * 100),
        isTopTen: rank <= 10
    };
}