// api/reports/export.js

/**
 * Report Export API Endpoint
 * Exports reports in various formats (PDF, CSV, Excel)
 * 
 * @route POST /api/reports/export
 * @access Private (Admin, Chairperson, Treasurer)
 */

const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit');
const { generateCSV, generatePDF, generateExcel } = require('../utils/export-formatters');

module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow POST requests
    if (req.method !== 'POST') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Check authorization
        if (!authorizeRoles(user, ['admin', 'chairperson', 'treasurer'])) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        // Get request body
        const { reportType, format, params = {} } = req.body;

        if (!reportType || !format) {
            return res.status(400).json({
                success: false,
                error: 'Report type and format are required'
            });
        }

        // Fetch report data based on type
        let reportData;
        switch (reportType) {
            case 'individual':
                reportData = await fetchIndividualReport(params);
                break;
            case 'group':
                reportData = await fetchGroupReport(params);
                break;
            case 'monthly':
                reportData = await fetchMonthlyReport(params);
                break;
            case 'transactions':
                reportData = await fetchTransactionLog(params);
                break;
            default:
                return res.status(400).json({
                    success: false,
                    error: 'Invalid report type'
                });
        }

        // Generate export file based on format
        let fileContent, contentType, filename;

        switch (format) {
            case 'csv':
                fileContent = generateCSV(reportData);
                contentType = 'text/csv';
                filename = `${reportType}_report_${new Date().toISOString().split('T')[0]}.csv`;
                break;
            case 'excel':
                fileContent = generateExcel(reportData);
                contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                filename = `${reportType}_report_${new Date().toISOString().split('T')[0]}.xlsx`;
                break;
            case 'pdf':
                fileContent = generatePDF(reportData);
                contentType = 'application/pdf';
                filename = `${reportType}_report_${new Date().toISOString().split('T')[0]}.pdf`;
                break;
            default:
                return res.status(400).json({
                    success: false,
                    error: 'Invalid export format'
                });
        }

        // Log export
        await logAuditEvent({
            action: 'REPORT_EXPORTED',
            userId: user.id,
            username: user.username,
            reportType,
            format,
            params,
            timestamp: new Date().toISOString()
        });

        // Set response headers for file download
        res.setHeader('Content-Type', contentType);
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.setHeader('Content-Length', fileContent.length);

        // Send file
        return res.status(200).send(fileContent);

    } catch (error) {
        console.error('Error exporting report:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to export report'
        });
    }
};

/**
 * Fetch individual member report
 */
async function fetchIndividualReport(params) {
    const { memberId, startDate, endDate } = params;
    
    const users = await githubStorage.readFile('users.json');
    const transactions = await githubStorage.readFile('transactions.json');

    const member = users.find(u => u.id === memberId);
    if (!member) throw new Error('Member not found');

    let memberTransactions = transactions.filter(t => t.memberId === memberId);

    if (startDate) {
        memberTransactions = memberTransactions.filter(t => t.date >= startDate);
    }
    if (endDate) {
        memberTransactions = memberTransactions.filter(t => t.date <= endDate);
    }

    return {
        member,
        transactions: memberTransactions.sort((a, b) => new Date(b.date) - new Date(a.date)),
        summary: {
            totalDeposits: memberTransactions.filter(t => t.type === 'deposit').reduce((s, t) => s + t.amount, 0),
            totalWithdrawals: memberTransactions.filter(t => t.type === 'withdrawal').reduce((s, t) => s + t.amount, 0),
            count: memberTransactions.length
        }
    };
}

/**
 * Fetch group report
 */
async function fetchGroupReport(params) {
    const { includeInactive } = params;
    
    const users = await githubStorage.readFile('users.json');
    const transactions = await githubStorage.readFile('transactions.json');

    const activeUsers = includeInactive ? users : users.filter(u => u.status === 'active');

    // Calculate group statistics
    const groupData = {
        members: activeUsers.map(u => ({ id: u.id, name: u.name, role: u.role })),
        totalMembers: activeUsers.length,
        transactions: transactions.length,
        totalSavings: transactions.reduce((sum, t) => t.type === 'deposit' ? sum + t.amount : sum - t.amount, 0)
    };

    return groupData;
}

/**
 * Fetch monthly report
 */
async function fetchMonthlyReport(params) {
    const { year, month } = params;
    
    const targetMonth = `${year}-${String(month).padStart(2, '0')}`;
    const transactions = await githubStorage.readFile('transactions.json');

    const monthlyTransactions = transactions.filter(t => t.date.startsWith(targetMonth));

    return {
        month: targetMonth,
        transactions: monthlyTransactions,
        total: monthlyTransactions.reduce((sum, t) => sum + t.amount, 0),
        count: monthlyTransactions.length
    };
}

/**
 * Fetch transaction log
 */
async function fetchTransactionLog(params) {
    const { startDate, endDate, memberId } = params;
    
    const transactions = await githubStorage.readFile('transactions.json');

    let filtered = [...transactions];

    if (startDate) {
        filtered = filtered.filter(t => t.date >= startDate);
    }
    if (endDate) {
        filtered = filtered.filter(t => t.date <= endDate);
    }
    if (memberId) {
        filtered = filtered.filter(t => t.memberId === memberId);
    }

    return filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
}