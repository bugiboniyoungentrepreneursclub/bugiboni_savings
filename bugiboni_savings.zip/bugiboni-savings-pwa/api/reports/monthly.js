// api/reports/monthly.js

/**
 * Monthly Contribution Report API Endpoint
 * Generates detailed monthly contribution analysis
 * 
 * @route GET /api/reports/monthly
 * @access Private (Admin, Chairperson, Treasurer)
 */

const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit');

module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow GET requests
    if (req.method !== 'GET') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Check authorization
        if (!authorizeRoles(user, ['admin', 'chairperson', 'treasurer'])) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        // Get parameters
        const { year, month, memberId } = req.query;

        if (!year || !month) {
            return res.status(400).json({
                success: false,
                error: 'Year and month are required'
            });
        }

        // Format month for filtering
        const targetMonth = `${year}-${String(month).padStart(2, '0')}`;

        // Read data
        const users = await githubStorage.readFile('users.json');
        const transactions = await githubStorage.readFile('transactions.json');

        // Filter transactions for the specified month
        const monthlyTransactions = transactions.filter(t => 
            t.date.startsWith(targetMonth)
        );

        // Filter by member if specified
        let filteredTransactions = monthlyTransactions;
        if (memberId) {
            filteredTransactions = filteredTransactions.filter(t => t.memberId === memberId);
        }

        // Group by member
        const memberContributions = {};
        const memberList = memberId 
            ? users.filter(u => u.id === memberId)
            : users.filter(u => u.role !== 'admin' && u.status === 'active');

        memberList.forEach(m => {
            memberContributions[m.id] = {
                memberId: m.id,
                memberName: m.name,
                total: 0,
                deposits: [],
                count: 0,
                hasContributed: false
            };
        });

        // Calculate contributions
        filteredTransactions.forEach(t => {
            if (memberContributions[t.memberId]) {
                memberContributions[t.memberId].total += t.amount;
                memberContributions[t.memberId].deposits.push({
                    id: t.id,
                    date: t.date,
                    amount: t.amount,
                    recordedBy: t.recordedByName
                });
                memberContributions[t.memberId].count++;
                memberContributions[t.memberId].hasContributed = true;
            }
        });

        // Sort deposits by date
        Object.values(memberContributions).forEach(m => {
            m.deposits.sort((a, b) => new Date(b.date) - new Date(a.date));
        });

        // Calculate summary statistics
        const contributingMembers = Object.values(memberContributions).filter(m => m.hasContributed);
        const totalContributions = contributingMembers.reduce((sum, m) => sum + m.total, 0);
        const averageContribution = contributingMembers.length > 0 
            ? totalContributions / contributingMembers.length 
            : 0;

        // Calculate daily totals
        const dailyTotals = {};
        filteredTransactions.forEach(t => {
            const day = t.date;
            if (!dailyTotals[day]) {
                dailyTotals[day] = 0;
            }
            dailyTotals[day] += t.amount;
        });

        // Prepare daily summary
        const dailySummary = Object.entries(dailyTotals)
            .map(([date, total]) => ({
                date,
                total,
                transactionCount: filteredTransactions.filter(t => t.date === date).length
            }))
            .sort((a, b) => a.date.localeCompare(b.date));

        // Prepare report
        const reportData = {
            generatedAt: new Date().toISOString(),
            generatedBy: {
                id: user.id,
                name: user.name,
                role: user.role
            },
            month: {
                year: parseInt(year),
                month: parseInt(month),
                name: new Date(year, month - 1).toLocaleString('default', { month: 'long' }),
                targetMonth
            },
            summary: {
                totalContributions,
                totalTransactions: filteredTransactions.length,
                contributingMembers: contributingMembers.length,
                totalMembers: memberList.length,
                participationRate: (contributingMembers.length / memberList.length) * 100,
                averageContribution,
                maxContribution: Math.max(...contributingMembers.map(m => m.total), 0),
                minContribution: Math.min(...contributingMembers.map(m => m.total), 0)
            },
            dailySummary,
            memberContributions: Object.values(memberContributions)
                .sort((a, b) => b.total - a.total),
            topContributors: Object.values(memberContributions)
                .filter(m => m.hasContributed)
                .sort((a, b) => b.total - a.total)
                .slice(0, 5),
            nonContributors: Object.values(memberContributions)
                .filter(m => !m.hasContributed)
                .map(m => ({
                    memberId: m.memberId,
                    memberName: m.memberName
                }))
        };

        // Add trend analysis if previous month data exists
        const prevMonth = getPreviousMonth(year, month);
        const prevMonthTransactions = transactions.filter(t => 
            t.date.startsWith(prevMonth)
        );
        
        if (prevMonthTransactions.length > 0) {
            const prevTotal = prevMonthTransactions.reduce((sum, t) => sum + t.amount, 0);
            const change = ((totalContributions - prevTotal) / prevTotal) * 100;
            
            reportData.trend = {
                previousMonth: prevMonth,
                previousTotal: prevTotal,
                change: change.toFixed(2),
                direction: change >= 0 ? 'increase' : 'decrease'
            };
        }

        // Log report generation
        await logAuditEvent({
            action: 'MONTHLY_REPORT_GENERATED',
            userId: user.id,
            username: user.username,
            month: targetMonth,
            memberId: memberId || 'all',
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            data: reportData
        });

    } catch (error) {
        console.error('Error generating monthly report:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to generate monthly report'
        });
    }
};

/**
 * Get previous month in YYYY-MM format
 */
function getPreviousMonth(year, month) {
    if (month === 1) {
        return `${year - 1}-12`;
    } else {
        return `${year}-${String(month - 1).padStart(2, '0')}`;
    }
}