// api/reports/group.js

/**
 * Group Summary Report API Endpoint
 * Generates comprehensive group savings report
 * 
 * @route GET /api/reports/group
 * @access Private (Admin, Chairperson, Treasurer)
 */

const githubStorage = require('../utils/github-storage');
const { authenticateToken, authorizeRoles } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit');

module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow GET requests
    if (req.method !== 'GET') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Check authorization
        if (!authorizeRoles(user, ['admin', 'chairperson', 'treasurer'])) {
            return res.status(403).json({
                success: false,
                error: 'Insufficient permissions'
            });
        }

        // Get parameters
        const { includeInactive = 'false', groupBy = 'month' } = req.query;

        // Read data
        const users = await githubStorage.readFile('users.json');
        const transactions = await githubStorage.readFile('transactions.json');

        // Filter active members if needed
        const activeUsers = includeInactive === 'true' 
            ? users 
            : users.filter(u => u.status === 'active' && u.role !== 'admin');

        // Calculate group statistics
        let totalGroupSavings = 0;
        const memberStats = {};
        const monthlyTotals = {};
        const memberBalances = {};

        // Initialize member stats
        activeUsers.forEach(u => {
            memberBalances[u.id] = 0;
            memberStats[u.id] = {
                memberId: u.id,
                memberName: u.name,
                role: u.role,
                deposits: 0,
                withdrawals: 0,
                count: 0,
                lastTransaction: null
            };
        });

        // Process transactions
        transactions.forEach(t => {
            // Skip if member not in our filtered list
            if (!memberStats[t.memberId]) return;

            const stats = memberStats[t.memberId];
            const amount = t.amount;

            if (t.type === 'deposit') {
                stats.deposits += amount;
                memberBalances[t.memberId] += amount;
                totalGroupSavings += amount;
            } else {
                stats.withdrawals += amount;
                memberBalances[t.memberId] -= amount;
                totalGroupSavings -= amount;
            }
            stats.count++;

            // Update last transaction
            if (!stats.lastTransaction || t.date > stats.lastTransaction) {
                stats.lastTransaction = t.date;
            }

            // Monthly aggregation
            const month = t.date.substring(0, 7);
            if (!monthlyTotals[month]) {
                monthlyTotals[month] = {
                    deposits: 0,
                    withdrawals: 0,
                    count: 0,
                    uniqueMembers: new Set()
                };
            }
            if (t.type === 'deposit') {
                monthlyTotals[month].deposits += amount;
            } else {
                monthlyTotals[month].withdrawals += amount;
            }
            monthlyTotals[month].count++;
            monthlyTotals[month].uniqueMembers.add(t.memberId);
        });

        // Calculate final balances
        Object.values(memberStats).forEach(stats => {
            stats.netSavings = memberBalances[stats.memberId];
        });

        // Sort members by savings
        const sortedMembers = Object.values(memberStats)
            .sort((a, b) => b.netSavings - a.netSavings);

        // Calculate overall statistics
        const activeMembers = Object.values(memberStats).filter(m => m.count > 0);
        const totalActiveMembers = activeMembers.length;

        const overallStats = {
            totalMembers: activeUsers.length,
            activeMembers: totalActiveMembers,
            inactiveMembers: activeUsers.length - totalActiveMembers,
            totalGroupSavings,
            averageSavings: totalActiveMembers > 0 ? totalGroupSavings / totalActiveMembers : 0,
            medianSavings: calculateMedian(sortedMembers.map(m => m.netSavings)),
            totalTransactions: transactions.length,
            totalDeposits: Object.values(memberStats).reduce((sum, m) => sum + m.deposits, 0),
            totalWithdrawals: Object.values(memberStats).reduce((sum, m) => sum + m.withdrawals, 0)
        };

        // Prepare monthly summary
        const monthlySummary = Object.entries(monthlyTotals)
            .map(([month, data]) => ({
                month,
                deposits: data.deposits,
                withdrawals: data.withdrawals,
                netChange: data.deposits - data.withdrawals,
                count: data.count,
                uniqueMembers: data.uniqueMembers.size
            }))
            .sort((a, b) => a.month.localeCompare(b.month));

        // Get top savers
        const topSavers = sortedMembers.slice(0, 10).map(m => ({
            memberId: m.memberId,
            memberName: m.memberName,
            totalSavings: m.netSavings,
            depositCount: m.count,
            lastTransaction: m.lastTransaction
        }));

        // Get members needing attention (no activity in 30+ days)
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        const inactiveMembers = Object.values(memberStats)
            .filter(m => {
                if (!m.lastTransaction) return true;
                return new Date(m.lastTransaction) < thirtyDaysAgo;
            })
            .map(m => ({
                memberId: m.memberId,
                memberName: m.memberName,
                lastTransaction: m.lastTransaction,
                currentBalance: m.netSavings
            }));

        // Prepare report
        const reportData = {
            generatedAt: new Date().toISOString(),
            generatedBy: {
                id: user.id,
                name: user.name,
                role: user.role
            },
            groupInfo: {
                name: 'Bugiboni Young Entrepreneurs',
                totalMembers: activeUsers.length,
                activeMembers: totalActiveMembers,
                asOf: new Date().toISOString().split('T')[0]
            },
            overall: overallStats,
            monthlySummary,
            memberSummary: sortedMembers,
            topSavers,
            inactiveMembers,
            insights: generateGroupInsights(overallStats, monthlySummary, topSavers)
        };

        // Log report generation
        await logAuditEvent({
            action: 'GROUP_REPORT_GENERATED',
            userId: user.id,
            username: user.username,
            includeInactive,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            data: reportData
        });

    } catch (error) {
        console.error('Error generating group report:', error);
        return res.status(500).json({
            success: false,
            error: 'Failed to generate group report'
        });
    }
};

/**
 * Calculate median of an array
 */
function calculateMedian(arr) {
    if (arr.length === 0) return 0;
    const sorted = [...arr].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 !== 0 
        ? sorted[mid] 
        : (sorted[mid - 1] + sorted[mid]) / 2;
}

/**
 * Generate insights from group data
 */
function generateGroupInsights(overall, monthly, topSavers) {
    const insights = [];

    // Growth trend
    if (monthly.length >= 2) {
        const lastMonth = monthly[monthly.length - 1];
        const prevMonth = monthly[monthly.length - 2];
        const growth = ((lastMonth.netChange - prevMonth.netChange) / prevMonth.netChange) * 100;

        if (growth > 10) {
            insights.push({
                type: 'positive',
                message: `Group savings grew by ${growth.toFixed(1)}% this month!`
            });
        } else if (growth < -10) {
            insights.push({
                type: 'warning',
                message: `Group savings decreased by ${Math.abs(growth).toFixed(1)}% this month.`
            });
        }
    }

    // Member participation
    const participationRate = (overall.activeMembers / overall.totalMembers) * 100;
    if (participationRate < 50) {
        insights.push({
            type: 'warning',
            message: `Only ${participationRate.toFixed(1)}% of members are actively saving.`
        });
    } else if (participationRate > 80) {
        insights.push({
            type: 'positive',
            message: `Great participation! ${participationRate.toFixed(1)}% of members are active.`
        });
    }

    // Top saver recognition
    if (topSavers.length > 0) {
        insights.push({
            type: 'info',
            message: `${topSavers[0].memberName} is the top saver with ${formatCurrency(topSavers[0].totalSavings)}`
        });
    }

    return insights;
}