// api/auth/login.js

/**
 * Login API Endpoint
 * Handles user authentication and returns JWT token
 * 
 * @route POST /api/auth/login
 * @access Public
 */

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const githubStorage = require('../utils/github-storage');
const { validateLoginInput, sanitizeInput } = require('../utils/validation');
const { logAuditEvent } = require('../utils/audit');

// JWT configuration
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const JWT_EXPIRES_IN = '8h';
const MAX_LOGIN_ATTEMPTS = 5;
const LOCKOUT_TIME = 15 * 60 * 1000; // 15 minutes in milliseconds

// In-memory store for login attempts (consider using Redis in production)
const loginAttempts = new Map();

/**
 * Clean up old login attempts periodically
 */
setInterval(() => {
    const now = Date.now();
    for (const [key, value] of loginAttempts.entries()) {
        if (value.lockoutUntil && value.lockoutUntil < now) {
            loginAttempts.delete(key);
        }
    }
}, 60 * 1000); // Clean up every minute

/**
 * Main login handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow POST requests
    if (req.method !== 'POST') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Parse request body
        const { username, password } = req.body;

        // Validate input
        const validationError = validateLoginInput(username, password);
        if (validationError) {
            return res.status(400).json({
                success: false,
                error: validationError
            });
        }

        // Sanitize username
        const sanitizedUsername = sanitizeInput(username.toLowerCase().trim());

        // Check for brute force attacks
        const ipAddress = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
        const attemptKey = `${sanitizedUsername}:${ipAddress}`;
        
        if (isUserLocked(attemptKey)) {
            const attempts = loginAttempts.get(attemptKey);
            const remainingTime = Math.ceil((attempts.lockoutUntil - Date.now()) / 1000 / 60);
            
            return res.status(429).json({
                success: false,
                error: `Too many failed attempts. Please try again in ${remainingTime} minutes.`
            });
        }

        // Read users from GitHub storage
        const users = await githubStorage.readFile('users.json');
        
        // Find user by username
        const user = users.find(u => u.username === sanitizedUsername);
        
        // Check if user exists
        if (!user) {
            // Record failed attempt
            recordFailedAttempt(attemptKey);
            
            // Log failed login attempt
            await logAuditEvent({
                action: 'LOGIN_FAILED',
                username: sanitizedUsername,
                ipAddress,
                reason: 'User not found',
                timestamp: new Date().toISOString()
            });
            
            return res.status(401).json({
                success: false,
                error: 'Invalid username or password'
            });
        }

        // Check if account is active
        if (user.status === 'inactive' || user.status === 'suspended') {
            await logAuditEvent({
                action: 'LOGIN_BLOCKED',
                username: sanitizedUsername,
                ipAddress,
                reason: `Account ${user.status}`,
                timestamp: new Date().toISOString()
            });
            
            return res.status(403).json({
                success: false,
                error: 'Your account is currently inactive. Please contact administrator.'
            });
        }

        // Verify password
        const isValidPassword = await bcrypt.compare(password, user.password);
        
        if (!isValidPassword) {
            // Record failed attempt
            recordFailedAttempt(attemptKey);
            
            // Log failed login attempt
            await logAuditEvent({
                action: 'LOGIN_FAILED',
                userId: user.id,
                username: sanitizedUsername,
                ipAddress,
                reason: 'Invalid password',
                timestamp: new Date().toISOString()
            });
            
            return res.status(401).json({
                success: false,
                error: 'Invalid username or password'
            });
        }

        // Successful login - clear failed attempts
        loginAttempts.delete(attemptKey);

        // Update last login information
        const lastLogin = {
            timestamp: new Date().toISOString(),
            ipAddress,
            userAgent: req.headers['user-agent']
        };

        // Update user's last login in storage (async, don't wait)
        updateUserLastLogin(user.id, lastLogin).catch(console.error);

        // Generate JWT token
        const token = jwt.sign(
            {
                id: user.id,
                username: user.username,
                role: user.role,
                name: user.name
            },
            JWT_SECRET,
            { expiresIn: JWT_EXPIRES_IN }
        );

        // Remove sensitive data from user object
        const { password: _, ...userWithoutPassword } = user;

        // Add last login info
        userWithoutPassword.lastLogin = lastLogin;

        // Log successful login
        await logAuditEvent({
            action: 'LOGIN_SUCCESS',
            userId: user.id,
            username: user.username,
            ipAddress,
            userAgent: req.headers['user-agent'],
            timestamp: new Date().toISOString()
        });

        // Set secure cookie with token (optional, can be used alongside header)
        res.setHeader('Set-Cookie', [
            `token=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${8 * 60 * 60}`,
            `session_active=true; Secure; SameSite=Strict; Path=/; Max-Age=${8 * 60 * 60}`
        ]);

        // Return success response
        return res.status(200).json({
            success: true,
            token,
            user: userWithoutPassword,
            message: 'Login successful'
        });

    } catch (error) {
        console.error('Login error:', error);
        
        // Log error
        await logAuditEvent({
            action: 'LOGIN_ERROR',
            error: error.message,
            ipAddress: req.headers['x-forwarded-for'] || req.socket.remoteAddress,
            timestamp: new Date().toISOString()
        });

        return res.status(500).json({
            success: false,
            error: 'An internal server error occurred. Please try again later.'
        });
    }
};

/**
 * Check if user is locked out
 */
function isUserLocked(key) {
    const attempts = loginAttempts.get(key);
    if (!attempts) return false;
    
    if (attempts.lockoutUntil && attempts.lockoutUntil > Date.now()) {
        return true;
    }
    
    // Clear expired lockout
    if (attempts.lockoutUntil && attempts.lockoutUntil <= Date.now()) {
        loginAttempts.delete(key);
        return false;
    }
    
    return false;
}

/**
 * Record failed login attempt
 */
function recordFailedAttempt(key) {
    const now = Date.now();
    let attempts = loginAttempts.get(key) || { count: 0, firstAttempt: now };
    
    attempts.count++;
    
    // Check if should lock out
    if (attempts.count >= MAX_LOGIN_ATTEMPTS) {
        attempts.lockoutUntil = now + LOCKOUT_TIME;
        attempts.count = 0; // Reset count after lockout
    }
    
    loginAttempts.set(key, attempts);
}

/**
 * Update user's last login information
 */
async function updateUserLastLogin(userId, lastLoginData) {
    try {
        const users = await githubStorage.readFile('users.json');
        const userIndex = users.findIndex(u => u.id === userId);
        
        if (userIndex !== -1) {
            users[userIndex].lastLogin = lastLoginData;
            users[userIndex].loginCount = (users[userIndex].loginCount || 0) + 1;
            
            await githubStorage.writeFile(
                'users.json', 
                users, 
                `Update last login for user ${userId}`
            );
        }
    } catch (error) {
        console.error('Error updating last login:', error);
        // Non-critical error, don't throw
    }
}

// ===== ADDITIONAL SECURITY MIDDLEWARE =====

/**
 * Rate limiting configuration (can be moved to separate file)
 */
const rateLimit = new Map();

function checkRateLimit(ip) {
    const now = Date.now();
    const windowMs = 15 * 60 * 1000; // 15 minutes
    const maxRequests = 100; // Maximum requests per window
    
    const userRate = rateLimit.get(ip) || { count: 0, resetTime: now + windowMs };
    
    if (now > userRate.resetTime) {
        userRate.count = 1;
        userRate.resetTime = now + windowMs;
    } else {
        userRate.count++;
    }
    
    rateLimit.set(ip, userRate);
    
    return userRate.count <= maxRequests;
}

// Export additional utilities for testing
module.exports.testUtils = {
    isUserLocked,
    recordFailedAttempt,
    checkRateLimit
};