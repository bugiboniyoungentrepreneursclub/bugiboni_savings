// api/auth/change-password.js

/**
 * Change Password API Endpoint
 * Allows authenticated users to change their password
 * 
 * @route POST /api/auth/change-password
 * @access Private
 */

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const githubStorage = require('../utils/github-storage');
const { authenticateToken } = require('../utils/auth-middleware');
const { validatePassword } = require('../utils/validation');
const { logAuditEvent } = require('../utils/audit');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

/**
 * Main change password handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow POST requests
    if (req.method !== 'POST') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Authenticate user
        const token = req.headers.authorization?.split(' ')[1];
        const user = authenticateToken(token);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'Authentication required'
            });
        }

        // Get request body
        const { currentPassword, newPassword, confirmPassword } = req.body;

        // Validate input
        if (!currentPassword || !newPassword || !confirmPassword) {
            return res.status(400).json({
                success: false,
                error: 'All fields are required'
            });
        }

        // Check if new password matches confirmation
        if (newPassword !== confirmPassword) {
            return res.status(400).json({
                success: false,
                error: 'New password and confirmation do not match'
            });
        }

        // Validate password strength
        const passwordValidation = validatePassword(newPassword);
        if (!passwordValidation.isValid) {
            return res.status(400).json({
                success: false,
                error: 'Password does not meet security requirements',
                feedback: passwordValidation.feedback
            });
        }

        // Get user from storage
        const users = await githubStorage.readFile('users.json');
        const userIndex = users.findIndex(u => u.id === user.id);

        if (userIndex === -1) {
            return res.status(404).json({
                success: false,
                error: 'User not found'
            });
        }

        const storedUser = users[userIndex];

        // Verify current password
        const isValidPassword = await bcrypt.compare(currentPassword, storedUser.password);
        if (!isValidPassword) {
            // Log failed password change attempt
            await logAuditEvent({
                action: 'PASSWORD_CHANGE_FAILED',
                userId: user.id,
                username: user.username,
                reason: 'Invalid current password',
                ipAddress: req.headers['x-forwarded-for'] || req.socket.remoteAddress,
                timestamp: new Date().toISOString()
            });

            return res.status(401).json({
                success: false,
                error: 'Current password is incorrect'
            });
        }

        // Check if new password is same as old
        const isSamePassword = await bcrypt.compare(newPassword, storedUser.password);
        if (isSamePassword) {
            return res.status(400).json({
                success: false,
                error: 'New password must be different from current password'
            });
        }

        // Hash new password
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        // Update user password
        users[userIndex].password = hashedPassword;
        users[userIndex].passwordChangedAt = new Date().toISOString();
        users[userIndex].passwordVersion = (storedUser.passwordVersion || 0) + 1;

        // Save to storage
        await githubStorage.writeFile(
            'users.json',
            users,
            `Password changed for user ${user.id}`
        );

        // Get client info
        const ipAddress = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
        const userAgent = req.headers['user-agent'];

        // Log successful password change
        await logAuditEvent({
            action: 'PASSWORD_CHANGE_SUCCESS',
            userId: user.id,
            username: user.username,
            ipAddress,
            userAgent,
            timestamp: new Date().toISOString()
        });

        // Generate new token (optional - force re-login with new password)
        const newToken = jwt.sign(
            {
                id: user.id,
                username: user.username,
                role: user.role,
                name: user.name,
                pv: users[userIndex].passwordVersion // Include password version in token
            },
            JWT_SECRET,
            { expiresIn: '8h' }
        );

        return res.status(200).json({
            success: true,
            message: 'Password changed successfully',
            token: newToken, // Optional: issue new token
            passwordChangedAt: users[userIndex].passwordChangedAt
        });

    } catch (error) {
        console.error('Change password error:', error);

        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};