// api/auth/reset-password.js

/**
 * Password Reset API Endpoint
 * Handles password reset requests and token verification
 * 
 * @route POST /api/auth/reset-password
 * @access Public
 */

const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const githubStorage = require('../utils/github-storage');
const { validateEmail, validatePassword } = require('../utils/validation');
const { logAuditEvent } = require('../utils/audit');
const { sendEmail } = require('../utils/email');

// Store for reset tokens (consider using Redis in production)
const resetTokens = new Map();

// Clean up expired tokens every hour
setInterval(() => {
    const now = Date.now();
    for (const [key, value] of resetTokens.entries()) {
        if (value.expiresAt < now) {
            resetTokens.delete(key);
        }
    }
}, 60 * 60 * 1000);

/**
 * Request password reset
 */
async function handleRequestReset(req, res) {
    const { email, username } = req.body;

    if (!email && !username) {
        return res.status(400).json({
            success: false,
            error: 'Email or username is required'
        });
    }

    // Validate email if provided
    if (email && !validateEmail(email)) {
        return res.status(400).json({
            success: false,
            error: 'Invalid email format'
        });
    }

    // Find user
    const users = await githubStorage.readFile('users.json');
    const user = email 
        ? users.find(u => u.email === email)
        : users.find(u => u.username === username);

    // Always return success to prevent user enumeration
    if (!user) {
        // Log attempt for monitoring
        await logAuditEvent({
            action: 'PASSWORD_RESET_ATTEMPT',
            identifier: email || username,
            reason: 'User not found',
            ipAddress: req.headers['x-forwarded-for'] || req.socket.remoteAddress,
            timestamp: new Date().toISOString()
        });

        return res.status(200).json({
            success: true,
            message: 'If the account exists, a reset link will be sent'
        });
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    const hashedToken = crypto
        .createHash('sha256')
        .update(resetToken)
        .digest('hex');

    // Store token with expiration (1 hour)
    resetTokens.set(hashedToken, {
        userId: user.id,
        expiresAt: Date.now() + 60 * 60 * 1000,
        used: false
    });

    // Create reset URL
    const resetUrl = `${process.env.APP_URL || 'https://bugiboni-savings.vercel.app'}/reset-password?token=${resetToken}`;

    // Send email
    try {
        await sendEmail({
            to: user.email,
            subject: 'Password Reset Request - Bugiboni Savings',
            html: `
                <h1>Password Reset Request</h1>
                <p>Hello ${user.name},</p>
                <p>You requested to reset your password for your Bugiboni Savings account.</p>
                <p>Click the link below to reset your password. This link will expire in 1 hour.</p>
                <p><a href="${resetUrl}">Reset Password</a></p>
                <p>If you didn't request this, please ignore this email.</p>
                <p>Stay safe,<br>Bugiboni Young Entrepreneurs</p>
            `
        });

        // Log successful reset request
        await logAuditEvent({
            action: 'PASSWORD_RESET_REQUESTED',
            userId: user.id,
            username: user.username,
            ipAddress: req.headers['x-forwarded-for'] || req.socket.remoteAddress,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('Error sending reset email:', error);
        // Still return success to prevent enumeration
    }

    return res.status(200).json({
        success: true,
        message: 'If the account exists, a reset link will be sent'
    });
}

/**
 * Verify reset token
 */
async function handleVerifyToken(req, res) {
    const { token } = req.body;

    if (!token) {
        return res.status(400).json({
            success: false,
            error: 'Token is required'
        });
    }

    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    const resetData = resetTokens.get(hashedToken);

    if (!resetData || resetData.expiresAt < Date.now() || resetData.used) {
        return res.status(400).json({
            success: false,
            error: 'Invalid or expired token'
        });
    }

    return res.status(200).json({
        success: true,
        message: 'Token is valid'
    });
}

/**
 * Reset password with token
 */
async function handleResetPassword(req, res) {
    const { token, newPassword, confirmPassword } = req.body;

    // Validate input
    if (!token || !newPassword || !confirmPassword) {
        return res.status(400).json({
            success: false,
            error: 'All fields are required'
        });
    }

    // Check password confirmation
    if (newPassword !== confirmPassword) {
        return res.status(400).json({
            success: false,
            error: 'Passwords do not match'
        });
    }

    // Validate password strength
    const passwordValidation = validatePassword(newPassword);
    if (!passwordValidation.isValid) {
        return res.status(400).json({
            success: false,
            error: 'Password does not meet security requirements',
            feedback: passwordValidation.feedback
        });
    }

    // Verify token
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    const resetData = resetTokens.get(hashedToken);

    if (!resetData || resetData.expiresAt < Date.now() || resetData.used) {
        return res.status(400).json({
            success: false,
            error: 'Invalid or expired token'
        });
    }

    // Get user
    const users = await githubStorage.readFile('users.json');
    const userIndex = users.findIndex(u => u.id === resetData.userId);

    if (userIndex === -1) {
        return res.status(404).json({
            success: false,
            error: 'User not found'
        });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update user password
    users[userIndex].password = hashedPassword;
    users[userIndex].passwordChangedAt = new Date().toISOString();
    users[userIndex].passwordVersion = (users[userIndex].passwordVersion || 0) + 1;

    // Save to storage
    await githubStorage.writeFile(
        'users.json',
        users,
        `Password reset for user ${resetData.userId}`
    );

    // Mark token as used
    resetData.used = true;
    resetTokens.set(hashedToken, resetData);

    // Log password reset
    await logAuditEvent({
        action: 'PASSWORD_RESET_COMPLETED',
        userId: users[userIndex].id,
        username: users[userIndex].username,
        ipAddress: req.headers['x-forwarded-for'] || req.socket.remoteAddress,
        timestamp: new Date().toISOString()
    });

    // Send confirmation email
    try {
        await sendEmail({
            to: users[userIndex].email,
            subject: 'Password Reset Successful - Bugiboni Savings',
            html: `
                <h1>Password Reset Successful</h1>
                <p>Hello ${users[userIndex].name},</p>
                <p>Your password has been successfully reset.</p>
                <p>If you didn't perform this action, please contact your administrator immediately.</p>
                <p>Stay safe,<br>Bugiboni Young Entrepreneurs</p>
            `
        });
    } catch (error) {
        console.error('Error sending confirmation email:', error);
    }

    return res.status(200).json({
        success: true,
        message: 'Password reset successful'
    });
}

/**
 * Main handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow POST requests
    if (req.method !== 'POST') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        const { action } = req.query;

        switch (action) {
            case 'request':
                return await handleRequestReset(req, res);
            case 'verify':
                return await handleVerifyToken(req, res);
            case 'reset':
                return await handleResetPassword(req, res);
            default:
                return res.status(400).json({
                    success: false,
                    error: 'Invalid action'
                });
        }

    } catch (error) {
        console.error('Password reset error:', error);

        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};

// Export utilities for testing
module.exports.utils = {
    resetTokens
};