// api/auth/session.js

/**
 * Session Verification API Endpoint
 * Verifies if the current session/token is valid
 * 
 * @route GET /api/auth/session
 * @access Private
 */

const jwt = require('jsonwebtoken');
const githubStorage = require('../utils/github-storage');
const { authenticateToken } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

/**
 * Main session handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow GET requests
    if (req.method !== 'GET') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Get token from Authorization header
        const authHeader = req.headers.authorization;
        const token = authHeader && authHeader.split(' ')[1];

        // Get token from cookies if not in header
        const cookieToken = req.headers.cookie
            ?.split(';')
            .find(c => c.trim().startsWith('token='))
            ?.split('=')[1];

        const finalToken = token || cookieToken;

        if (!finalToken) {
            return res.status(401).json({
                valid: false,
                authenticated: false,
                error: 'No token provided'
            });
        }

        // Verify token
        let decoded;
        try {
            decoded = jwt.verify(finalToken, JWT_SECRET);
        } catch (error) {
            if (error.name === 'TokenExpiredError') {
                return res.status(401).json({
                    valid: false,
                    authenticated: false,
                    error: 'Token expired',
                    expired: true
                });
            }
            
            return res.status(401).json({
                valid: false,
                authenticated: false,
                error: 'Invalid token'
            });
        }

        // Get fresh user data from storage
        const users = await githubStorage.readFile('users.json');
        const user = users.find(u => u.id === decoded.id);

        if (!user) {
            return res.status(401).json({
                valid: false,
                authenticated: false,
                error: 'User not found'
            });
        }

        // Check if account is still active
        if (user.status === 'inactive' || user.status === 'suspended') {
            return res.status(403).json({
                valid: false,
                authenticated: false,
                error: `Account is ${user.status}`,
                status: user.status
            });
        }

        // Check if password was changed after token issuance
        if (user.passwordChangedAt && decoded.iat) {
            const passwordChangedTime = new Date(user.passwordChangedAt).getTime() / 1000;
            if (passwordChangedTime > decoded.iat) {
                return res.status(401).json({
                    valid: false,
                    authenticated: false,
                    error: 'Password changed. Please login again.',
                    passwordChanged: true
                });
            }
        }

        // Remove sensitive data
        const { password, ...userWithoutPassword } = user;

        // Log session check (optional - can be noisy)
        if (process.env.LOG_SESSION_CHECKS === 'true') {
            await logAuditEvent({
                action: 'SESSION_CHECK',
                userId: user.id,
                username: user.username,
                ipAddress: req.headers['x-forwarded-for'] || req.socket.remoteAddress,
                timestamp: new Date().toISOString()
            }).catch(console.error);
        }

        // Return session data
        return res.status(200).json({
            valid: true,
            authenticated: true,
            user: userWithoutPassword,
            expiresIn: decoded.exp ? decoded.exp * 1000 - Date.now() : null,
            issuedAt: decoded.iat ? new Date(decoded.iat * 1000).toISOString() : null,
            permissions: getUserPermissions(user.role)
        });

    } catch (error) {
        console.error('Session verification error:', error);

        return res.status(500).json({
            valid: false,
            authenticated: false,
            error: 'Internal server error'
        });
    }
};

/**
 * Get permissions for user role
 */
function getUserPermissions(role) {
    const permissions = {
        admin: [
            'manage_users',
            'manage_roles',
            'view_audit',
            'configure_system',
            'view_all_reports',
            'export_data',
            'manage_backup',
            'view_financial_summary'
        ],
        chairperson: [
            'manage_users',
            'view_reports',
            'view_financial_summary',
            'export_data',
            'view_member_list',
            'send_announcements'
        ],
        treasurer: [
            'record_deposits',
            'view_transactions',
            'view_financial_history',
            'generate_reports',
            'view_member_balances',
            'send_payment_confirmations'
        ],
        secretary: [
            'view_member_list',
            'view_financial_summary',
            'view_reports',
            'send_announcements'
        ],
        welfare: [
            'view_member_list',
            'view_financial_summary'
        ],
        discipline: [
            'view_member_list',
            'view_financial_summary'
        ],
        projects: [
            'view_member_list',
            'view_financial_summary'
        ],
        member: [
            'view_own_balance',
            'view_own_transactions',
            'view_own_profile'
        ]
    };

    return permissions[role] || [];
}