// api/auth/refresh.js

/**
 * Token Refresh API Endpoint
 * Issues a new JWT token using a valid refresh token
 * 
 * @route POST /api/auth/refresh
 * @access Public (with valid refresh token)
 */

const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const githubStorage = require('../utils/github-storage');
const { logAuditEvent } = require('../utils/audit');

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';
const REFRESH_TOKEN_SECRET = process.env.REFRESH_TOKEN_SECRET || 'your-refresh-secret-change-in-production';
const JWT_EXPIRES_IN = '8h';
const REFRESH_TOKEN_EXPIRES_IN = '7d';

// Store for refresh tokens (consider using Redis in production)
const refreshTokenStore = new Map();

/**
 * Main refresh handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow POST requests
    if (req.method !== 'POST') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Get refresh token from request
        const { refreshToken } = req.body;
        const cookieRefreshToken = req.headers.cookie
            ?.split(';')
            .find(c => c.trim().startsWith('refresh_token='))
            ?.split('=')[1];

        const finalRefreshToken = refreshToken || cookieRefreshToken;

        if (!finalRefreshToken) {
            return res.status(401).json({
                success: false,
                error: 'Refresh token required'
            });
        }

        // Verify refresh token
        let decoded;
        try {
            decoded = jwt.verify(finalRefreshToken, REFRESH_TOKEN_SECRET);
        } catch (error) {
            return res.status(401).json({
                success: false,
                error: 'Invalid or expired refresh token'
            });
        }

        // Check if refresh token is in store (optional - for token revocation)
        const storedToken = refreshTokenStore.get(decoded.id);
        if (storedToken && storedToken !== finalRefreshToken) {
            return res.status(401).json({
                success: false,
                error: 'Refresh token has been revoked'
            });
        }

        // Get fresh user data
        const users = await githubStorage.readFile('users.json');
        const user = users.find(u => u.id === decoded.id);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'User not found'
            });
        }

        // Check account status
        if (user.status === 'inactive' || user.status === 'suspended') {
            return res.status(403).json({
                success: false,
                error: `Account is ${user.status}`
            });
        }

        // Generate new access token
        const newToken = jwt.sign(
            {
                id: user.id,
                username: user.username,
                role: user.role,
                name: user.name
            },
            JWT_SECRET,
            { expiresIn: JWT_EXPIRES_IN }
        );

        // Generate new refresh token (optional - refresh token rotation)
        const newRefreshToken = jwt.sign(
            { id: user.id, version: Date.now() },
            REFRESH_TOKEN_SECRET,
            { expiresIn: REFRESH_TOKEN_EXPIRES_IN }
        );

        // Store new refresh token (revoke old one)
        refreshTokenStore.set(user.id, newRefreshToken);

        // Get client info
        const ipAddress = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
        const userAgent = req.headers['user-agent'];

        // Log token refresh
        await logAuditEvent({
            action: 'TOKEN_REFRESH',
            userId: user.id,
            username: user.username,
            ipAddress,
            userAgent,
            timestamp: new Date().toISOString()
        });

        // Set cookies
        res.setHeader('Set-Cookie', [
            `token=${newToken}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${8 * 60 * 60}`,
            `refresh_token=${newRefreshToken}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${7 * 24 * 60 * 60}`,
            `session_active=true; Secure; SameSite=Strict; Path=/; Max-Age=${8 * 60 * 60}`
        ]);

        // Remove sensitive data
        const { password, ...userWithoutPassword } = user;

        return res.status(200).json({
            success: true,
            token: newToken,
            refreshToken: newRefreshToken,
            user: userWithoutPassword,
            expiresIn: 8 * 60 * 60 * 1000 // 8 hours in milliseconds
        });

    } catch (error) {
        console.error('Token refresh error:', error);

        return res.status(500).json({
            success: false,
            error: 'Internal server error'
        });
    }
};

/**
 * Revoke refresh token (for logout)
 */
async function revokeRefreshToken(userId) {
    refreshTokenStore.delete(userId);
}

/**
 * Get active refresh tokens count (for monitoring)
 */
function getActiveRefreshTokenCount() {
    return refreshTokenStore.size;
}

// Export utilities
module.exports.utils = {
    revokeRefreshToken,
    getActiveRefreshTokenCount,
    refreshTokenStore
};