// api/auth/logout.js

/**
 * Logout API Endpoint
 * Handles user logout, token invalidation, and session cleanup
 * 
 * @route POST /api/auth/logout
 * @access Private
 */

const githubStorage = require('../utils/github-storage');
const { authenticateToken } = require('../utils/auth-middleware');
const { logAuditEvent } = require('../utils/audit');

// Token blacklist (consider using Redis in production)
const tokenBlacklist = new Set();

// Clean up blacklisted tokens periodically (every hour)
setInterval(() => {
    tokenBlacklist.clear();
    console.log('Token blacklist cleared');
}, 60 * 60 * 1000);

/**
 * Main logout handler
 */
module.exports = async (req, res) => {
    // Set CORS headers
    res.setHeader('Access-Control-Allow-Credentials', true);
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
    res.setHeader(
        'Access-Control-Allow-Headers',
        'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, Authorization'
    );

    // Handle preflight requests
    if (req.method === 'OPTIONS') {
        res.status(200).end();
        return;
    }

    // Only allow POST requests
    if (req.method !== 'POST') {
        return res.status(405).json({ 
            success: false,
            error: 'Method not allowed' 
        });
    }

    try {
        // Get token from Authorization header
        const authHeader = req.headers.authorization;
        const token = authHeader && authHeader.split(' ')[1];

        // Get token from cookies if not in header
        const cookieToken = req.headers.cookie
            ?.split(';')
            .find(c => c.trim().startsWith('token='))
            ?.split('=')[1];

        const finalToken = token || cookieToken;

        if (!finalToken) {
            // No token to invalidate, but still consider logout successful
            return res.status(200).json({
                success: true,
                message: 'Logout successful'
            });
        }

        // Authenticate token (optional - we'll try to get user info even if token is invalid)
        let user = null;
        try {
            user = authenticateToken(finalToken);
        } catch (error) {
            // Token might be expired or invalid, but we'll still proceed with logout
            console.log('Token authentication failed during logout:', error.message);
        }

        // Add token to blacklist
        tokenBlacklist.add(finalToken);

        // Get client information
        const ipAddress = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
        const userAgent = req.headers['user-agent'];

        // Log logout event if we have user info
        if (user) {
            await logAuditEvent({
                action: 'LOGOUT',
                userId: user.id,
                username: user.username,
                ipAddress,
                userAgent,
                timestamp: new Date().toISOString(),
                details: {
                    method: 'explicit',
                    tokenBlacklisted: true
                }
            });

            // Update user's last logout time
            await updateUserLastLogout(user.id).catch(console.error);
        } else {
            // Log anonymous logout
            await logAuditEvent({
                action: 'LOGOUT_ANONYMOUS',
                ipAddress,
                userAgent,
                timestamp: new Date().toISOString(),
                details: {
                    method: 'explicit',
                    tokenPresent: !!finalToken
                }
            });
        }

        // Clear cookies
        res.setHeader('Set-Cookie', [
            'token=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0',
            'session_active=; Secure; SameSite=Strict; Path=/; Max-Age=0',
            'refresh_token=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0'
        ]);

        // Return success response
        return res.status(200).json({
            success: true,
            message: 'Logout successful',
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('Logout error:', error);

        // Log error
        await logAuditEvent({
            action: 'LOGOUT_ERROR',
            error: error.message,
            ipAddress: req.headers['x-forwarded-for'] || req.socket.remoteAddress,
            timestamp: new Date().toISOString()
        });

        // Even if there's an error, we want to clear client-side tokens
        // So we still return success with appropriate headers
        res.setHeader('Set-Cookie', [
            'token=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0',
            'session_active=; Secure; SameSite=Strict; Path=/; Max-Age=0',
            'refresh_token=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0'
        ]);

        return res.status(200).json({
            success: true,
            message: 'Logout processed',
            warning: 'Server encountered an issue but logout completed'
        });
    }
};

/**
 * Update user's last logout time
 */
async function updateUserLastLogout(userId) {
    try {
        const users = await githubStorage.readFile('users.json');
        const userIndex = users.findIndex(u => u.id === userId);

        if (userIndex !== -1) {
            users[userIndex].lastLogout = {
                timestamp: new Date().toISOString(),
                method: 'explicit'
            };

            await githubStorage.writeFile(
                'users.json',
                users,
                `Update last logout for user ${userId}`
            );
        }
    } catch (error) {
        console.error('Error updating last logout:', error);
        // Non-critical error, don't throw
    }
}

/**
 * Check if token is blacklisted
 */
function isTokenBlacklisted(token) {
    return tokenBlacklist.has(token);
}

/**
 * Get blacklist size (for monitoring)
 */
function getBlacklistSize() {
    return tokenBlacklist.size;
}

// Export additional utilities
module.exports.utils = {
    isTokenBlacklisted,
    getBlacklistSize,
    tokenBlacklist
};