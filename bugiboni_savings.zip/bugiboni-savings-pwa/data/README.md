# Bugiboni Young Entrepreneurs Savings Management System PWA

A comprehensive Progressive Web App for managing group savings with role-based access control, WhatsApp integration, and offline capabilities.

## 🌟 Features

### User Management
- **Multi-role System**: Admin, Chairperson, Treasurer, Secretary, Welfare, Discipline, Projects, and Member roles
- **Role-Based Access Control**: Granular permissions per role
- **User Profiles**: Complete member information with WhatsApp integration
- **Activity Tracking**: Last login, transaction history, and audit trail

### Financial Management
- **Deposit Recording**: Quick and easy deposit entry
- **Transaction History**: Complete audit trail of all financial activities
- **Balance Tracking**: Real-time individual and group savings calculation
- **Receipt Generation**: Automatic receipt numbers for each transaction
- **Verification Workflow**: Treasurer verification for all transactions

### Reporting & Analytics
- **Individual Statements**: Detailed member savings statements
- **Group Summaries**: Overall group savings statistics
- **Monthly Reports**: Monthly contribution analysis
- **Export Options**: PDF, CSV, and Excel export formats
- **Data Visualization**: Charts and graphs for trends

### Communication
- **WhatsApp Integration**: Automatic payment confirmations
- **Email Notifications**: Transaction alerts and statements
- **Group Announcements**: Broadcast messages to members
- **Payment Confirmations**: Real-time SMS/WhatsApp alerts

### PWA Features
- **Installable**: Add to home screen on Android devices
- **Offline Support**: Access data without internet
- **Push Notifications**: Real-time alerts
- **Fast Loading**: Optimized performance
- **Mobile-First**: Responsive design for all devices

### Security
- **JWT Authentication**: Secure token-based authentication
- **Password Hashing**: bcrypt password encryption
- **Rate Limiting**: Protection against brute force attacks
- **Audit Logging**: Complete audit trail of all actions
- **Session Management**: Automatic timeout after inactivity

## 📋 Prerequisites

- Node.js 18.x or higher
- npm 9.x or higher
- GitHub account (for storage)
- Vercel account (for deployment)
- WhatsApp Business API (optional)

## 🚀 Quick Start

### 1. Clone the Repository
```bash
git clone https://github.com/yourusername/bugiboni-savings-pwa.git
cd bugiboni-savings-pwa